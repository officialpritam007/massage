package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.CallType
import com.example.data.repository.ActiveCallState
import com.example.ui.components.LosslessBadge
import com.example.ui.components.liquidGlass
import com.example.ui.theme.LiquidCyan
import com.example.ui.theme.LiquidEmerald
import com.example.ui.theme.LiquidGlassBorder
import com.example.ui.theme.LiquidGlassBorderBrush
import com.example.ui.theme.LiquidGlassHighlight
import com.example.ui.theme.LiquidMagenta
import com.example.ui.theme.LiquidViolet

@Composable
fun CallScreen(
    callState: ActiveCallState,
    onEndCall: () -> Unit,
    onToggleMute: () -> Unit,
    onToggleVideo: () -> Unit,
    onFlipCamera: () -> Unit,
    onToggleSpeaker: () -> Unit
) {
    BackHandler {
        onEndCall()
    }

    val contact = callState.contact ?: return
    val isVideo = callState.callType == CallType.VIDEO

    val minutes = callState.durationSeconds / 60
    val seconds = callState.durationSeconds % 60
    val durationText = String.format("%02d:%02d", minutes, seconds)

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070B14))
            .testTag("active_call_screen")
    ) {
        // Video background if video call and not disabled
        if (isVideo && !callState.isVideoDisabled) {
            AsyncImage(
                model = contact.avatarUrl,
                contentDescription = "Video Stream",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Frosted dark overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0x99000000),
                                Color(0x33000000),
                                Color(0xCC050811)
                            )
                        )
                    )
            )
        } else {
            // Liquid Glass Audio Wave Backdrop
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF1B294A),
                                Color(0xFF0F182B),
                                Color(0xFF070B14)
                            ),
                            center = Offset(500f, 700f),
                            radius = 1200f
                        )
                    )
            )
        }

        // Top Glass Telemetry Bar
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier
                    .liquidGlass(
                        shape = RoundedCornerShape(20.dp),
                        backgroundColor = Color(0x3314223A),
                        borderBrush = LiquidGlassBorderBrush
                    )
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = LiquidEmerald,
                    modifier = Modifier.size(13.dp)
                )
                Text(
                    text = "256-BIT LIQUID E2EE",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "•",
                    color = Color(0xFF6B7E9C),
                    fontSize = 10.sp
                )
                Text(
                    text = callState.relayNode,
                    color = LiquidCyan,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = contact.name,
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = durationText,
                color = LiquidCyan,
                fontSize = 16.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(6.dp))

            LosslessBadge(
                text = if (isVideo) "AV1 1080P60 LOSSLESS VIDEO" else "OPUS 48kHz LOSSLESS AUDIO"
            )
        }

        // Center Visualizer (Audio or Fallback)
        if (!isVideo || callState.isVideoDisabled) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(260.dp),
                contentAlignment = Alignment.Center
            ) {
                // Pulsing Glass Wave Rings
                Box(
                    modifier = Modifier
                        .size(240.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .border(1.5.dp, Brush.radialGradient(listOf(LiquidCyan.copy(alpha = 0.4f), Color.Transparent)), CircleShape)
                )
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .scale(pulseScale * 0.88f)
                        .clip(CircleShape)
                        .border(1.2.dp, Brush.radialGradient(listOf(LiquidViolet.copy(alpha = 0.5f), Color.Transparent)), CircleShape)
                )

                // Avatar container
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .clip(CircleShape)
                        .border(2.dp, LiquidGlassBorderBrush, CircleShape)
                ) {
                    AsyncImage(
                        model = contact.avatarUrl,
                        contentDescription = contact.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        } else {
            // Picture-in-Picture Self Camera Preview (Simulated Liquid Glass)
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 130.dp, end = 20.dp)
                    .size(width = 110.dp, height = 155.dp)
                    .liquidGlass(
                        shape = RoundedCornerShape(18.dp),
                        backgroundColor = Color(0x40162540),
                        borderBrush = LiquidGlassBorderBrush
                    )
                    .clip(RoundedCornerShape(18.dp))
            ) {
                // Self preview placeholder / camera
                AsyncImage(
                    model = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80",
                    contentDescription = "Self Camera",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0x80000000))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (callState.isFrontCamera) "Front" else "Rear",
                        color = Color.White,
                        fontSize = 9.sp
                    )
                }
            }
        }

        // Bottom Liquid Glass Controls Dock
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 36.dp)
                .liquidGlass(
                    shape = RoundedCornerShape(32.dp),
                    backgroundColor = Color(0x4D121B2F),
                    borderBrush = LiquidGlassBorderBrush
                )
                .padding(horizontal = 16.dp, vertical = 18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mute Mic Button
                IconButton(
                    onClick = onToggleMute,
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(if (callState.isMuted) Color(0x66FF3B30) else Color(0x2EFFFFFF))
                        .border(1.dp, LiquidGlassBorder, CircleShape)
                        .testTag("call_mute_button")
                ) {
                    Icon(
                        imageVector = if (callState.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute Microphone",
                        tint = if (callState.isMuted) Color.White else LiquidCyan,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Video Toggle (if video call)
                if (isVideo) {
                    IconButton(
                        onClick = onToggleVideo,
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(if (callState.isVideoDisabled) Color(0x66FF9500) else Color(0x2EFFFFFF))
                            .border(1.dp, LiquidGlassBorder, CircleShape)
                            .testTag("call_video_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (callState.isVideoDisabled) Icons.Default.VideocamOff else Icons.Default.Videocam,
                            contentDescription = "Toggle Video",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Flip Camera
                    IconButton(
                        onClick = onFlipCamera,
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(Color(0x2EFFFFFF))
                            .border(1.dp, LiquidGlassBorder, CircleShape)
                            .testTag("call_flip_camera_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FlipCameraAndroid,
                            contentDescription = "Flip Camera",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                } else {
                    // Speakerphone Toggle
                    IconButton(
                        onClick = onToggleSpeaker,
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(if (callState.isSpeakerOn) Color(0x4000F2FE) else Color(0x2EFFFFFF))
                            .border(1.dp, LiquidGlassBorder, CircleShape)
                            .testTag("call_speaker_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Speakerphone",
                            tint = if (callState.isSpeakerOn) LiquidCyan else Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // End Call Button (Glowing Red Liquid Glass)
                IconButton(
                    onClick = onEndCall,
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFFFF3B30), Color(0xFFFF2A85))
                            )
                        )
                        .border(1.2.dp, LiquidGlassBorderBrush, CircleShape)
                        .testTag("call_end_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "End Call",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }
    }
}
