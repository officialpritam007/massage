package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LiquidCyan
import com.example.ui.theme.LiquidDeepObsidian
import com.example.ui.theme.LiquidEmerald
import com.example.ui.theme.LiquidGlassBorderBrush
import com.example.ui.theme.LiquidMagenta
import com.example.ui.theme.LiquidViolet

// Preset Gradients for Liquid Text Statuses
val LiquidStatusGradients = listOf(
    Brush.linearGradient(listOf(Color(0xFF00C6FF), Color(0xFF0072FF), Color(0xFF7000FF))),
    Brush.linearGradient(listOf(Color(0xFFFF2A85), Color(0xFF8A2BE2), Color(0xFF4A00E0))),
    Brush.linearGradient(listOf(Color(0xFF00F5A0), Color(0xFF00D2FF), Color(0xFF0047FF))),
    Brush.linearGradient(listOf(Color(0xFFFFB300), Color(0xFFFF416C), Color(0xFF8A2BE2))),
    Brush.linearGradient(listOf(Color(0xFF051937), Color(0xFF004D7A), Color(0xFF008793), Color(0xFF00BF72)))
)

/**
 * Pure iOS 26 Liquid Glass modifier:
 * Translucent frosted glass tint + dual-gradient specular reflection edge
 * + top caustic light highlight to simulate real liquid glass depth.
 */
fun Modifier.liquidGlass(
    shape: Shape = RoundedCornerShape(26.dp),
    backgroundColor: Color = Color(0x2E18263E),
    borderWidth: Dp = 1.dp,
    borderBrush: Brush = Brush.linearGradient(
        colors = listOf(
            Color(0x99FFFFFF),
            Color(0x25FFFFFF),
            Color(0x0AFFFFFF),
            Color(0x40FFFFFF)
        )
    )
): Modifier = this
    .clip(shape)
    .background(backgroundColor, shape)
    .border(borderWidth, borderBrush, shape)

/**
 * Dynamic liquid glass styling driven directly by user's UiCustomizationConfig.
 */
fun Modifier.liquidGlassDynamic(
    config: com.example.data.model.UiCustomizationConfig?,
    shape: Shape = RoundedCornerShape(24.dp),
    baseColorHex: Long = 0xFF14233CL
): Modifier {
    val opacity = config?.glassOpacity ?: 0.28f
    val borderAlpha = config?.specularBorderAlpha ?: 0.55f
    val bgColor = Color(baseColorHex).copy(alpha = opacity)
    val specularBrush = Brush.linearGradient(
        listOf(
            Color.White.copy(alpha = borderAlpha),
            Color.White.copy(alpha = borderAlpha * 0.25f),
            Color.Transparent,
            Color.White.copy(alpha = borderAlpha * 0.4f)
        )
    )
    return this
        .clip(shape)
        .background(bgColor, shape)
        .border(0.9.dp, specularBrush, shape)
}

/**
 * Ultra-clean liquid pill container with smooth rounded curve and soft reflection.
 */
fun Modifier.liquidPill(
    backgroundColor: Color = Color(0x35142138),
    borderBrush: Brush = LiquidGlassBorderBrush
): Modifier = this
    .clip(CircleShape)
    .background(backgroundColor, CircleShape)
    .border(0.8.dp, borderBrush, CircleShape)

/**
 * Creates dynamic ambient liquid backdrop with glowing fluid mesh orbs.
 * Adds subtle floating caustics and breathing luminous gradients for maximum liquidity.
 */
@Composable
fun LiquidAmbientBackdrop(
    modifier: Modifier = Modifier,
    config: com.example.data.model.UiCustomizationConfig? = null,
    content: @Composable () -> Unit
) {
    val theme = config?.backdropTheme ?: com.example.data.model.BackdropTheme.IRIDESCENT_FLUID
    val enableOrbs = config?.enableDynamicOrbs ?: true
    val primaryColor = config?.primaryAccent ?: LiquidCyan
    val secondaryColor = config?.secondaryAccent ?: LiquidViolet

    val infiniteTransition = rememberInfiniteTransition(label = "liquid_orbs")

    val orb1Offset by infiniteTransition.animateFloat(
        initialValue = -40f,
        targetValue = 50f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 7000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb1"
    )

    val orb2Offset by infiniteTransition.animateFloat(
        initialValue = 30f,
        targetValue = -50f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 9500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb2"
    )

    val waveShimmer by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(LiquidDeepObsidian)
            .drawBehind {
                val width = size.width
                val height = size.height

                // Base deep cosmic glass depth based on theme
                val baseGradient = when (theme) {
                    com.example.data.model.BackdropTheme.DEEP_COSMIC -> listOf(
                        Color(0xFF060914),
                        Color(0xFF120C28),
                        Color(0xFF04060C)
                    )
                    com.example.data.model.BackdropTheme.EMERALD_MATRIX -> listOf(
                        Color(0xFF041210),
                        Color(0xFF0A221E),
                        Color(0xFF030A09)
                    )
                    com.example.data.model.BackdropTheme.PURE_OBSIDIAN -> listOf(
                        Color(0xFF06080D),
                        Color(0xFF090D14),
                        Color(0xFF030508)
                    )
                    com.example.data.model.BackdropTheme.AURORA_BOREALIS -> listOf(
                        Color(0xFF04181B),
                        Color(0xFF06221C),
                        Color(0xFF0D122B)
                    )
                    com.example.data.model.BackdropTheme.MERCURY_CHROME -> listOf(
                        Color(0xFF0F141C),
                        Color(0xFF1B232E),
                        Color(0xFF080C12)
                    )
                    else -> listOf(
                        Color(0xFF070B14),
                        Color(0xFF0C1322),
                        Color(0xFF060912)
                    )
                }

                drawRect(
                    brush = Brush.verticalGradient(colors = baseGradient)
                )

                if (enableOrbs && theme != com.example.data.model.BackdropTheme.PURE_OBSIDIAN) {
                    // Top-Right Liquid Pool
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                primaryColor.copy(alpha = 0.25f),
                                primaryColor.copy(alpha = 0.07f),
                                Color.Transparent
                            ),
                            center = Offset(width * 0.85f + orb1Offset, height * 0.12f + orb2Offset),
                            radius = width * 0.8f
                        )
                    )

                    // Mid-Left Luminous Pool
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                secondaryColor.copy(alpha = 0.22f),
                                secondaryColor.copy(alpha = 0.05f),
                                Color.Transparent
                            ),
                            center = Offset(width * 0.12f + orb2Offset, height * 0.48f - orb1Offset),
                            radius = width * 0.85f
                        )
                    )

                    // Bottom Pool
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                LiquidEmerald.copy(alpha = 0.14f),
                                primaryColor.copy(alpha = 0.04f),
                                Color.Transparent
                            ),
                            center = Offset(width * 0.5f - orb1Offset, height * 0.88f + orb2Offset),
                            radius = width * 0.75f
                        )
                    )

                    // Dynamic Caustic Specular Wave
                    val waveY = height * waveShimmer
                    drawRoundRect(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.05f),
                                Color.Transparent
                            ),
                            center = Offset(width * 0.5f, waveY),
                            radius = width * 0.65f
                        ),
                        topLeft = Offset(0f, waveY - 80f),
                        size = Size(width, 160f),
                        cornerRadius = CornerRadius(80f, 80f)
                    )
                }
            }
    ) {
        content()
    }
}
