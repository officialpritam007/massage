package com.example.data.repository

import com.example.data.db.AppDatabase
import com.example.data.model.CallDirection
import com.example.data.model.CallLogEntity
import com.example.data.model.CallType
import com.example.data.model.ChatEntity
import com.example.data.model.ContactEntity
import com.example.data.model.MediaType
import com.example.data.model.MessageEntity
import com.example.data.model.MessageStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

data class ActiveCallState(
    val isActive: Boolean = false,
    val contact: ContactEntity? = null,
    val callType: CallType = CallType.VIDEO,
    val durationSeconds: Int = 0,
    val isMuted: Boolean = false,
    val isVideoDisabled: Boolean = false,
    val isFrontCamera: Boolean = true,
    val isSpeakerOn: Boolean = true,
    val relayNode: String = "Zurich Hyper-Relay (14ms)",
    val bitrate: String = "4.2 Mbps Lossless",
    val encryptionBadge: String = "256-bit Liquid E2EE",
    val isConnected: Boolean = true
)

class ChatRepository(
    private val db: AppDatabase,
    private val scope: CoroutineScope
) {
    private val contactDao = db.contactDao()
    private val chatDao = db.chatDao()
    private val groupDao = db.groupDao()
    private val messageDao = db.messageDao()
    private val callLogDao = db.callLogDao()
    private val statusDao = db.statusDao()

    val allChats: Flow<List<ChatEntity>> = chatDao.getAllChats()
    val allGroups: Flow<List<com.example.data.model.GroupEntity>> = groupDao.getAllGroups()
    val allContacts: Flow<List<ContactEntity>> = contactDao.getAllContacts()
    val allCallLogs: Flow<List<CallLogEntity>> = callLogDao.getAllCallLogs()
    val allStatuses: Flow<List<com.example.data.model.StatusEntity>> = statusDao.getAllStatuses()

    private val _activeCall = MutableStateFlow<ActiveCallState?>(null)
    val activeCall = _activeCall.asStateFlow()

    private val _isSimulatedTyping = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val isSimulatedTyping = _isSimulatedTyping.asStateFlow()

    suspend fun createGroup(
        name: String,
        description: String,
        category: String,
        avatarUrl: String,
        memberIds: List<String>
    ): String {
        val groupId = "grp_" + System.currentTimeMillis()
        val now = System.currentTimeMillis()
        val membersStr = memberIds.joinToString(",")
        val group = com.example.data.model.GroupEntity(
            id = groupId,
            name = name,
            avatarUrl = avatarUrl.ifBlank { "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=400&q=80" },
            description = description.ifBlank { "End-to-end encrypted liquid group" },
            memberIds = membersStr,
            lastMessage = "Group created with ${memberIds.size + 1} members",
            lastMessageTime = now,
            lastSenderName = "System",
            unreadCount = 0,
            category = category,
            encryptionProtocol = "MLS TreeKEM v1 / 256-bit Ratchet",
            createdAt = now
        )
        groupDao.insertOrUpdateGroup(group)

        // Seed welcome message
        messageDao.insertMessage(
            MessageEntity(
                chatId = groupId,
                senderId = "me",
                content = "Welcome to $name! End-to-end encryption is active for all ${memberIds.size + 1} members.",
                timestamp = now,
                status = MessageStatus.READ,
                isEncrypted = true,
                isLossless = true
            )
        )
        return groupId
    }

    suspend fun getGroup(groupId: String): com.example.data.model.GroupEntity? {
        return groupDao.getGroupById(groupId)
    }

    suspend fun markGroupAsRead(groupId: String) {
        groupDao.markGroupAsRead(groupId)
    }

    suspend fun deleteGroup(groupId: String) {
        groupDao.deleteGroup(groupId)
    }

    suspend fun postStatus(caption: String, mediaUrl: String?, gradientIndex: Int) {
        val now = System.currentTimeMillis()
        statusDao.insertStatus(
            com.example.data.model.StatusEntity(
                contactId = "me",
                authorName = "My Status",
                authorAvatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80",
                mediaUrl = mediaUrl,
                textCaption = caption,
                backgroundGradientIndex = gradientIndex,
                timestamp = now,
                isViewed = false,
                viewsCount = 0,
                isLossless = true
            )
        )
    }

    suspend fun markStatusViewed(statusId: Long) {
        statusDao.markStatusAsViewed(statusId)
        statusDao.incrementViewCount(statusId)
    }

    suspend fun deleteStatus(statusId: Long) {
        statusDao.deleteStatus(statusId)
    }

    init {
        scope.launch(Dispatchers.IO) {
            seedInitialDataIfEmpty()
            startRealTimeSimulationLoop()
        }
    }

    fun getMessagesForChat(chatId: String): Flow<List<MessageEntity>> {
        return messageDao.getMessagesForChat(chatId)
    }

    suspend fun getContact(contactId: String): ContactEntity? {
        return contactDao.getContactById(contactId)
    }

    suspend fun markAsRead(chatId: String) {
        chatDao.markChatAsRead(chatId)
    }

    suspend fun sendTextMessage(chatId: String, content: String) {
        val now = System.currentTimeMillis()
        val msg = MessageEntity(
            chatId = chatId,
            senderId = "me",
            content = content,
            timestamp = now,
            status = MessageStatus.SENT,
            isEncrypted = true,
            isLossless = true
        )
        val msgId = messageDao.insertMessage(msg)
        updateChatHeader(chatId, content, now)

        // Simulate delivery & read
        scope.launch(Dispatchers.IO) {
            delay(900)
            messageDao.updateMessage(msg.copy(id = msgId, status = MessageStatus.DELIVERED))
            delay(1200)
            messageDao.updateMessage(msg.copy(id = msgId, status = MessageStatus.READ))
            triggerSimulatedReply(chatId, content)
        }
    }

    suspend fun sendLosslessMedia(
        chatId: String,
        mediaType: MediaType,
        mediaUri: String,
        mediaName: String,
        sizeBytes: Long,
        resolutionOrSpec: String,
        checksum: String,
        caption: String = ""
    ) {
        val now = System.currentTimeMillis()
        val content = if (caption.isNotBlank()) caption else "Lossless ${mediaType.name.lowercase()}: $mediaName"
        val msg = MessageEntity(
            chatId = chatId,
            senderId = "me",
            content = content,
            timestamp = now,
            status = MessageStatus.SENT,
            isEncrypted = true,
            mediaType = mediaType,
            mediaUri = mediaUri,
            mediaName = mediaName,
            mediaSizeBytes = sizeBytes,
            mediaResolution = resolutionOrSpec,
            mediaChecksum = checksum,
            isLossless = true
        )
        val msgId = messageDao.insertMessage(msg)
        updateChatHeader(chatId, "📁 $mediaName (Lossless)", now)

        scope.launch(Dispatchers.IO) {
            delay(800)
            messageDao.updateMessage(msg.copy(id = msgId, status = MessageStatus.DELIVERED))
            delay(1000)
            messageDao.updateMessage(msg.copy(id = msgId, status = MessageStatus.READ))
        }
    }

    suspend fun sendVoiceNote(
        chatId: String,
        durationSeconds: Int,
        waveform: String
    ) {
        val now = System.currentTimeMillis()
        val msg = MessageEntity(
            chatId = chatId,
            senderId = "me",
            content = "Voice note ($durationSeconds s)",
            timestamp = now,
            status = MessageStatus.SENT,
            isEncrypted = true,
            mediaType = MediaType.VOICE,
            audioDurationSeconds = durationSeconds,
            audioWaveform = waveform,
            isLossless = true,
            mediaResolution = "48kHz 24-bit Opus Studio"
        )
        val msgId = messageDao.insertMessage(msg)
        updateChatHeader(chatId, "🎙️ Voice note (${durationSeconds}s)", now)

        scope.launch(Dispatchers.IO) {
            delay(700)
            messageDao.updateMessage(msg.copy(id = msgId, status = MessageStatus.DELIVERED))
            delay(1100)
            messageDao.updateMessage(msg.copy(id = msgId, status = MessageStatus.READ))
        }
    }

    private suspend fun updateChatHeader(chatId: String, text: String, timestamp: Long, senderPrefix: String = "") {
        if (chatId.startsWith("grp_")) {
            val existingGroup = groupDao.getGroupById(chatId)
            if (existingGroup != null) {
                val formatted = if (senderPrefix.isNotBlank()) "$senderPrefix: $text" else text
                groupDao.insertOrUpdateGroup(
                    existingGroup.copy(
                        lastMessage = formatted,
                        lastMessageTime = timestamp,
                        lastSenderName = senderPrefix
                    )
                )
            }
        } else {
            val existing = chatDao.getChatById(chatId)
            if (existing != null) {
                chatDao.insertOrUpdateChat(existing.copy(lastMessage = text, lastMessageTime = timestamp))
            }
        }
    }

    fun startCall(contact: ContactEntity, type: CallType) {
        _activeCall.value = ActiveCallState(
            isActive = true,
            contact = contact,
            callType = type,
            durationSeconds = 0,
            relayNode = contact.relayNode,
            bitrate = if (type == CallType.VIDEO) "6.8 Mbps Lossless 1080p60" else "48kHz Opus 160kbps"
        )

        // Increment duration timer
        scope.launch {
            while (_activeCall.value?.isActive == true) {
                delay(1000)
                _activeCall.value = _activeCall.value?.copy(
                    durationSeconds = (_activeCall.value?.durationSeconds ?: 0) + 1
                )
            }
        }
    }

    fun toggleMute() {
        _activeCall.value?.let { current ->
            _activeCall.value = current.copy(isMuted = !current.isMuted)
        }
    }

    fun toggleVideo() {
        _activeCall.value?.let { current ->
            _activeCall.value = current.copy(isVideoDisabled = !current.isVideoDisabled)
        }
    }

    fun flipCamera() {
        _activeCall.value?.let { current ->
            _activeCall.value = current.copy(isFrontCamera = !current.isFrontCamera)
        }
    }

    fun toggleSpeaker() {
        _activeCall.value?.let { current ->
            _activeCall.value = current.copy(isSpeakerOn = !current.isSpeakerOn)
        }
    }

    fun endCall() {
        val current = _activeCall.value
        if (current != null && current.contact != null) {
            val duration = current.durationSeconds
            scope.launch(Dispatchers.IO) {
                callLogDao.insertCallLog(
                    CallLogEntity(
                        contactId = current.contact.id,
                        callType = current.callType,
                        direction = CallDirection.OUTGOING,
                        timestamp = System.currentTimeMillis(),
                        durationSeconds = duration
                    )
                )
            }
        }
        _activeCall.value = null
    }

    private suspend fun triggerSimulatedReply(chatId: String, userText: String) {
        if (chatId.startsWith("grp_")) {
            val group = groupDao.getGroupById(chatId) ?: return
            val memberList = group.memberIds.split(",").filter { it.isNotBlank() }
            val replyingMemberId = memberList.randomOrNull() ?: "elena"
            val contact = contactDao.getContactById(replyingMemberId)
            val memberFirstName = contact?.name?.split(" ")?.firstOrNull() ?: "Elena"

            _isSimulatedTyping.value = _isSimulatedTyping.value + (chatId to true)
            delay(1800)
            _isSimulatedTyping.value = _isSimulatedTyping.value - chatId

            val groupReplies = when {
                userText.contains("call", ignoreCase = true) || userText.contains("video", ignoreCase = true) -> listOf(
                    "Ready to join the group conference room whenever you initiate!",
                    "Node audio codec initialized. AV1 60fps ready on this side.",
                    "Connecting via Zurich Hyper-Relay. Latency is only 12ms."
                )
                userText.contains("media", ignoreCase = true) || userText.contains("photo", ignoreCase = true) -> listOf(
                    "Lossless file received by all members with 100% checksum match!",
                    "Uncompressed dynamic range looks breathtaking on our displays.",
                    "Downloaded the raw capture through peer-to-peer mesh. Instantaneous!"
                )
                else -> listOf(
                    "Synced with the MLS TreeKEM encryption state across all group nodes.",
                    "Agreed! The Liquid Glass interface and real-time mesh routing feel incredible.",
                    "Ratchet keys rotated successfully for all group members.",
                    "Verified the zero-knowledge signature. Looking forward to the demo!",
                    "All signals verified through our decentralized relays."
                )
            }
            val replyContent = groupReplies.random()
            val now = System.currentTimeMillis()

            messageDao.insertMessage(
                MessageEntity(
                    chatId = chatId,
                    senderId = replyingMemberId,
                    content = replyContent,
                    timestamp = now,
                    status = MessageStatus.READ,
                    isEncrypted = true,
                    isLossless = true
                )
            )
            updateChatHeader(chatId, replyContent, now, memberFirstName)
            return
        }

        val contactId = chatId
        val contact = contactDao.getContactById(contactId) ?: return

        // Set typing indicator
        _isSimulatedTyping.value = _isSimulatedTyping.value + (chatId to true)
        delay(2200)
        _isSimulatedTyping.value = _isSimulatedTyping.value - chatId

        val replyOptions = when {
            userText.contains("photo", ignoreCase = true) || userText.contains("video", ignoreCase = true) -> listOf(
                "Received in full uncompressed lossless resolution! The dynamic range looks pristine.",
                "Verified SHA-256 checksum matches 100%. No bit rot or quality compression.",
                "Spectacular clarity! Liquid glass renderer makes these colors pop on OLED."
            )
            userText.contains("call", ignoreCase = true) -> listOf(
                "Ready whenever you are! The global relay latency to your node is just 14ms.",
                "Let's jump on a lossless video call, switching to 60fps AV1 stream."
            )
            else -> listOf(
                "Verified your encrypted packet over Liquid Ratchet v4. All signals clear!",
                "Real-time sync confirmed across global mesh nodes.",
                "Received loud and clear! Beautiful liquid glass interface on your side?",
                "Got your lossless transmission. Zero artifacts, pure fidelity."
            )
        }
        val replyContent = replyOptions.random()
        val now = System.currentTimeMillis()

        messageDao.insertMessage(
            MessageEntity(
                chatId = chatId,
                senderId = contactId,
                content = replyContent,
                timestamp = now,
                status = MessageStatus.READ,
                isEncrypted = true,
                isLossless = true
            )
        )
        updateChatHeader(chatId, replyContent, now)
    }

    private suspend fun startRealTimeSimulationLoop() {
        // Periodically simulates background updates from the global contacts network
        while (true) {
            delay(35000)
            val contacts = listOf("elena", "liam", "aiko", "marcus")
            val selected = contacts.random()
            val contact = contactDao.getContactById(selected) ?: continue
            val randomPings = listOf(
                "Updating cryptographic ratchet session keys for today.",
                "Pushed the latest lossless architectural vector renders to the stream.",
                "Connection route optimized: now routed through Tokyo Liquid Relay (9ms).",
                "New lossless audio session ready for review whenever you are free."
            )
            val text = randomPings.random()
            val now = System.currentTimeMillis()

            messageDao.insertMessage(
                MessageEntity(
                    chatId = selected,
                    senderId = selected,
                    content = text,
                    timestamp = now,
                    status = MessageStatus.DELIVERED,
                    isEncrypted = true,
                    isLossless = true
                )
            )
            val existing = chatDao.getChatById(selected)
            if (existing != null) {
                chatDao.insertOrUpdateChat(
                    existing.copy(
                        lastMessage = text,
                        lastMessageTime = now,
                        unreadCount = existing.unreadCount + 1
                    )
                )
            }
        }
    }

    private suspend fun seedInitialDataIfEmpty() {
        val existing = chatDao.getChatById("elena")
        if (existing != null) return

        val contacts = listOf(
            ContactEntity(
                id = "elena",
                name = "Elena Rostova",
                avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80",
                statusText = "Synthesizing lossless audio stream 🎧",
                location = "Zurich, Switzerland",
                relayNode = "EU-Central (14ms)",
                isOnline = true,
                lastSeen = "Just now",
                publicKeyFingerprint = "7F82 • 43A1 • 9CE0 • 28BB • FA31 • 01DC"
            ),
            ContactEntity(
                id = "liam",
                name = "Liam Chen",
                avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80",
                statusText = "Testing 4K 60fps ProRes live relay",
                location = "Singapore",
                relayNode = "AP-Southeast (18ms)",
                isOnline = true,
                lastSeen = "2m ago",
                publicKeyFingerprint = "18BC • 92DF • 4488 • C310 • EE90 • 551A"
            ),
            ContactEntity(
                id = "aiko",
                name = "Aiko Tanaka",
                avatarUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=400&q=80",
                statusText = "Liquid glass shaders in iOS 26 look surreal ✨",
                location = "Tokyo, Japan",
                relayNode = "AP-Northeast (11ms)",
                isOnline = true,
                lastSeen = "Active",
                publicKeyFingerprint = "AA40 • 7821 • BBD9 • 9012 • 4F5A • CC39"
            ),
            ContactEntity(
                id = "marcus",
                name = "Marcus Vance",
                avatarUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80",
                statusText = "Hardware security module synced 🔒",
                location = "San Francisco, USA",
                relayNode = "US-West (22ms)",
                isOnline = false,
                lastSeen = "15m ago",
                publicKeyFingerprint = "5091 • EFA3 • 7712 • BB20 • 93A7 • DD18"
            ),
            ContactEntity(
                id = "sophia",
                name = "Sophia Rossi",
                avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80",
                statusText = "In design sprint • Lossless vector reviews",
                location = "Milan, Italy",
                relayNode = "EU-South (16ms)",
                isOnline = true,
                lastSeen = "Active",
                publicKeyFingerprint = "3E21 • BA78 • CC99 • 1102 • 88EF • 420A"
            )
        )
        contactDao.insertContacts(contacts)

        val now = System.currentTimeMillis()

        // Seed chats
        val chats = listOf(
            ChatEntity(
                id = "elena",
                contactId = "elena",
                lastMessage = "Here is the lossless 48MP RAW photo from the lab.",
                lastMessageTime = now - 1000 * 60 * 3,
                unreadCount = 1,
                isPinned = true,
                isE2EEActive = true
            ),
            ChatEntity(
                id = "liam",
                contactId = "liam",
                lastMessage = "Sent 4K ProRes capture (184 MB uncompressed)",
                lastMessageTime = now - 1000 * 60 * 25,
                unreadCount = 0,
                isPinned = true,
                isE2EEActive = true
            ),
            ChatEntity(
                id = "aiko",
                contactId = "aiko",
                lastMessage = "Verified the 256-bit handshake. Voice call quality is unreal!",
                lastMessageTime = now - 1000 * 60 * 90,
                unreadCount = 0,
                isPinned = false,
                isE2EEActive = true
            ),
            ChatEntity(
                id = "marcus",
                contactId = "marcus",
                lastMessage = "📁 quantum_encryption_spec_v4.pdf (Lossless 14.2 MB)",
                lastMessageTime = now - 1000 * 60 * 180,
                unreadCount = 0,
                isPinned = false,
                isE2EEActive = true
            ),
            ChatEntity(
                id = "sophia",
                contactId = "sophia",
                lastMessage = "Liquid glass border reflections look immaculate on dark OLED.",
                lastMessageTime = now - 1000 * 60 * 360,
                unreadCount = 0,
                isPinned = false,
                isE2EEActive = true
            )
        )
        chats.forEach { chatDao.insertOrUpdateChat(it) }

        // Seed Messages for Elena
        val elenaMessages = listOf(
            MessageEntity(
                chatId = "elena",
                senderId = "elena",
                content = "Hey! Have you seen the new Liquid Glass design language for iOS 26? It combines refractive depth with organic fluid blur.",
                timestamp = now - 1000 * 60 * 30,
                status = MessageStatus.READ,
                isEncrypted = true,
                isLossless = true
            ),
            MessageEntity(
                chatId = "elena",
                senderId = "me",
                content = "It feels incredible in person. Especially with real-time E2EE encryption enabled across our global nodes.",
                timestamp = now - 1000 * 60 * 24,
                status = MessageStatus.READ,
                isEncrypted = true,
                isLossless = true
            ),
            MessageEntity(
                chatId = "elena",
                senderId = "elena",
                content = "Voice note from Zurich studio",
                timestamp = now - 1000 * 60 * 15,
                status = MessageStatus.READ,
                isEncrypted = true,
                mediaType = MediaType.VOICE,
                audioDurationSeconds = 12,
                audioWaveform = "24,45,80,60,95,100,85,70,55,90,75,40,65,85,90,50,30,60,45,20",
                mediaResolution = "48kHz 24-bit Opus Studio Lossless",
                isLossless = true
            ),
            MessageEntity(
                chatId = "elena",
                senderId = "me",
                content = "The audio fidelity is crystal clear, 0 latency.",
                timestamp = now - 1000 * 60 * 10,
                status = MessageStatus.READ,
                isEncrypted = true,
                isLossless = true
            ),
            MessageEntity(
                chatId = "elena",
                senderId = "elena",
                content = "Here is the lossless 48MP RAW photo from the lab.",
                timestamp = now - 1000 * 60 * 3,
                status = MessageStatus.DELIVERED,
                isEncrypted = true,
                mediaType = MediaType.PHOTO,
                mediaUri = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=100",
                mediaName = "LQD_RAW_0942_HDR.dng",
                mediaSizeBytes = 47_820_000L, // 47.8 MB
                mediaResolution = "48MP (8064x6048) 14-bit DNG RAW",
                mediaChecksum = "SHA-256: d41d8cd98f00b204e9800998ecf8427e",
                isLossless = true
            )
        )
        elenaMessages.forEach { messageDao.insertMessage(it) }

        // Seed Liam's 4K video message
        val liamMessages = listOf(
            MessageEntity(
                chatId = "liam",
                senderId = "liam",
                content = "Testing our high-bitrate video engine through Singapore AP-Southeast node.",
                timestamp = now - 1000 * 60 * 40,
                status = MessageStatus.READ,
                isEncrypted = true,
                isLossless = true
            ),
            MessageEntity(
                chatId = "liam",
                senderId = "liam",
                content = "Sent 4K ProRes capture (184 MB uncompressed)",
                timestamp = now - 1000 * 60 * 25,
                status = MessageStatus.READ,
                isEncrypted = true,
                mediaType = MediaType.VIDEO,
                mediaUri = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=100",
                mediaName = "SINGAPORE_CYBERPUNK_4K60.mov",
                mediaSizeBytes = 193_450_000L, // 193.4 MB
                mediaResolution = "4K UHD 60fps (3840x2160) ProRes 422 HQ",
                mediaChecksum = "SHA-256: b294f81a70081d322ef5ab417b189ff4",
                isLossless = true
            )
        )
        liamMessages.forEach { messageDao.insertMessage(it) }

        // Seed Marcus's Document
        val marcusMessages = listOf(
            MessageEntity(
                chatId = "marcus",
                senderId = "marcus",
                content = "Quantum resistant key-exchange spec is ready for deployment.",
                timestamp = now - 1000 * 60 * 200,
                status = MessageStatus.READ,
                isEncrypted = true,
                isLossless = true
            ),
            MessageEntity(
                chatId = "marcus",
                senderId = "marcus",
                content = "Quantum resistant spec document",
                timestamp = now - 1000 * 60 * 180,
                status = MessageStatus.READ,
                isEncrypted = true,
                mediaType = MediaType.DOCUMENT,
                mediaUri = "content://docs/quantum_encryption_spec_v4.pdf",
                mediaName = "quantum_encryption_spec_v4.pdf",
                mediaSizeBytes = 14_850_000L, // 14.8 MB
                mediaResolution = "PDF 2.0 • 42 Pages • Vector Typography",
                mediaChecksum = "SHA-256: c59265f2122650074f07a2164d123891",
                isLossless = true
            )
        )
        marcusMessages.forEach { messageDao.insertMessage(it) }

        // Seed Call Logs
        val callLogs = listOf(
            CallLogEntity(
                contactId = "elena",
                callType = CallType.VIDEO,
                direction = CallDirection.INCOMING,
                timestamp = now - 1000 * 60 * 120,
                durationSeconds = 642,
                qualityCodec = "AV1 Lossless 1080p60 • Opus 48kHz"
            ),
            CallLogEntity(
                contactId = "aiko",
                callType = CallType.VOICE,
                direction = CallDirection.OUTGOING,
                timestamp = now - 1000 * 60 * 300,
                durationSeconds = 215,
                qualityCodec = "Opus Studio 48kHz E2EE"
            ),
            CallLogEntity(
                contactId = "liam",
                callType = CallType.VIDEO,
                direction = CallDirection.MISSED,
                timestamp = now - 1000 * 60 * 600,
                durationSeconds = 0,
                qualityCodec = "AV1 Lossless Stream"
            )
        )
        callLogs.forEach { callLogDao.insertCallLog(it) }

        // Seed WhatsApp-style Liquid Statuses
        val initialStatuses = listOf(
            com.example.data.model.StatusEntity(
                contactId = "elena",
                authorName = "Elena Rostova",
                authorAvatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80",
                mediaUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1000&q=80",
                textCaption = "Testing liquid refraction optics in Zurich 💎 Pure fluid physics",
                backgroundGradientIndex = 0,
                timestamp = now - 1000 * 60 * 18,
                isViewed = false,
                viewsCount = 42,
                isLossless = true
            ),
            com.example.data.model.StatusEntity(
                contactId = "liam",
                authorName = "Liam Chen",
                authorAvatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80",
                mediaUrl = "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=1000&q=80",
                textCaption = "4K HDR sunrise over Singapore marina 🌅 0% compression bitstream",
                backgroundGradientIndex = 1,
                timestamp = now - 1000 * 60 * 45,
                isViewed = false,
                viewsCount = 89,
                isLossless = true
            ),
            com.example.data.model.StatusEntity(
                contactId = "aiko",
                authorName = "Aiko Tanaka",
                authorAvatarUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=400&q=80",
                mediaUrl = null,
                textCaption = "iOS 26 liquid glass aesthetic is mesmerizing 🌊 Refraction everywhere!",
                backgroundGradientIndex = 2,
                timestamp = now - 1000 * 60 * 95,
                isViewed = true,
                viewsCount = 134,
                isLossless = true
            ),
            com.example.data.model.StatusEntity(
                contactId = "marcus",
                authorName = "Marcus Vance",
                authorAvatarUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80",
                mediaUrl = "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1000&q=80",
                textCaption = "All hardware security enclaves synced 🔒 256-bit zero-knowledge keys",
                backgroundGradientIndex = 3,
                timestamp = now - 1000 * 60 * 180,
                isViewed = true,
                viewsCount = 67,
                isLossless = true
            )
        )
        initialStatuses.forEach { statusDao.insertStatus(it) }

        // Seed Encrypted Groups
        val initialGroups = listOf(
            com.example.data.model.GroupEntity(
                id = "grp_liquid_core",
                name = "Liquid Core Engineers ⚡",
                avatarUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=400&q=80",
                description = "Core engine development for Liquid Glass UI and ultra-low latency mesh networking.",
                memberIds = "elena,liam,aiko,marcus,sophia",
                lastMessage = "Elena: Lossless audio and refractive depth pipeline verified",
                lastMessageTime = now - 1000 * 60 * 5,
                lastSenderName = "Elena",
                unreadCount = 2,
                isPinned = true,
                category = "Engineering",
                encryptionProtocol = "MLS TreeKEM v1 / 256-bit Ratchet",
                createdAt = now - 1000L * 60 * 60 * 24 * 7
            ),
            com.example.data.model.GroupEntity(
                id = "grp_quantum_lab",
                name = "Quantum Cryptography Lab 🔬",
                avatarUrl = "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=400&q=80",
                description = "Zero-knowledge protocols and post-quantum multi-party ratchet encryption.",
                memberIds = "marcus,elena,aiko",
                lastMessage = "Marcus: Kyber-1024 key exchange benchmark is under 4ms",
                lastMessageTime = now - 1000 * 60 * 45,
                lastSenderName = "Marcus",
                unreadCount = 0,
                isPinned = true,
                category = "Security",
                encryptionProtocol = "MLS TreeKEM v1 / 256-bit Ratchet",
                createdAt = now - 1000L * 60 * 60 * 24 * 14
            ),
            com.example.data.model.GroupEntity(
                id = "grp_zurich_studio",
                name = "Zurich Lossless Studio 🎧",
                avatarUrl = "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=400&q=80",
                description = "48kHz 24-bit Opus lossless audio mastering and ProRes HDR workflows.",
                memberIds = "elena,sophia,liam",
                lastMessage = "Sophia: Sent the 48kHz acoustic wave profile",
                lastMessageTime = now - 1000 * 60 * 110,
                lastSenderName = "Sophia",
                unreadCount = 1,
                isPinned = false,
                category = "Studio",
                encryptionProtocol = "MLS TreeKEM v1 / 256-bit Ratchet",
                createdAt = now - 1000L * 60 * 60 * 24 * 3
            ),
            com.example.data.model.GroupEntity(
                id = "grp_mesh_ops",
                name = "Global Mesh Relay Ops 🌐",
                avatarUrl = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=400&q=80",
                description = "Real-time edge relay health, latency routing, and decentralized peer discovery.",
                memberIds = "liam,marcus,elena",
                lastMessage = "Liam: Tokyo to Zurich latency dropped to 9ms via hyper-relay",
                lastMessageTime = now - 1000 * 60 * 220,
                lastSenderName = "Liam",
                unreadCount = 0,
                isPinned = false,
                category = "Network",
                encryptionProtocol = "MLS TreeKEM v1 / 256-bit Ratchet",
                createdAt = now - 1000L * 60 * 60 * 24 * 20
            )
        )
        groupDao.insertGroups(initialGroups)

        // Seed Group Messages for Liquid Core Engineers
        val coreGroupMessages = listOf(
            MessageEntity(
                chatId = "grp_liquid_core",
                senderId = "marcus",
                content = "Morning team! Quantum entropy pool has refreshed. All 5 member keys are synchronized.",
                timestamp = now - 1000 * 60 * 60,
                status = MessageStatus.READ,
                isEncrypted = true,
                isLossless = true
            ),
            MessageEntity(
                chatId = "grp_liquid_core",
                senderId = "liam",
                content = "Running 4K ProRes test packets through the mesh right now.",
                timestamp = now - 1000 * 60 * 35,
                status = MessageStatus.READ,
                isEncrypted = true,
                isLossless = true
            ),
            MessageEntity(
                chatId = "grp_liquid_core",
                senderId = "aiko",
                content = "Liquid glass shaders in Android are maintaining solid 60fps with zero frame drop ✨",
                timestamp = now - 1000 * 60 * 18,
                status = MessageStatus.READ,
                isEncrypted = true,
                isLossless = true
            ),
            MessageEntity(
                chatId = "grp_liquid_core",
                senderId = "elena",
                content = "Lossless audio and refractive depth pipeline verified",
                timestamp = now - 1000 * 60 * 5,
                status = MessageStatus.DELIVERED,
                isEncrypted = true,
                isLossless = true
            )
        )
        coreGroupMessages.forEach { messageDao.insertMessage(it) }

        // Seed Group Messages for Quantum Cryptography Lab
        val quantumMessages = listOf(
            MessageEntity(
                chatId = "grp_quantum_lab",
                senderId = "elena",
                content = "Did everyone review the TreeKEM epoch update?",
                timestamp = now - 1000 * 60 * 90,
                status = MessageStatus.READ,
                isEncrypted = true,
                isLossless = true
            ),
            MessageEntity(
                chatId = "grp_quantum_lab",
                senderId = "marcus",
                content = "Kyber-1024 key exchange benchmark is under 4ms",
                timestamp = now - 1000 * 60 * 45,
                status = MessageStatus.READ,
                isEncrypted = true,
                isLossless = true
            )
        )
        quantumMessages.forEach { messageDao.insertMessage(it) }
    }
}
