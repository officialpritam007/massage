package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import com.example.data.model.GroupEntity
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.CallLogEntity
import com.example.data.model.CallType
import com.example.data.model.ChatEntity
import com.example.data.model.ContactEntity
import com.example.data.model.StatusEntity
import com.example.ui.components.LiquidAmbientBackdrop
import com.example.ui.components.LosslessBadge
import com.example.ui.components.liquidGlass
import com.example.ui.components.liquidPill
import com.example.ui.theme.LiquidCyan
import com.example.ui.theme.LiquidEmerald
import com.example.ui.theme.LiquidGlassBorder
import com.example.ui.theme.LiquidGlassBorderBrush
import com.example.ui.theme.LiquidViolet
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

import com.example.data.model.AccountProfile
import com.example.data.model.UiCustomizationConfig
import com.example.ui.components.AccountSwitcherSheet
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.SwapHoriz

@Composable
fun HomeScreen(
    chats: List<ChatEntity>,
    groups: List<GroupEntity> = emptyList(),
    contactsMap: Map<String, ContactEntity>,
    contactsList: List<ContactEntity>,
    callLogs: List<CallLogEntity>,
    statuses: List<StatusEntity>,
    accounts: List<AccountProfile>,
    activeAccountId: String,
    uiConfig: UiCustomizationConfig,
    onSelectChat: (String) -> Unit,
    onStartCall: (ContactEntity, CallType) -> Unit,
    onPostStatus: (String, String?, Int) -> Unit,
    onMarkStatusViewed: (Long) -> Unit,
    onDeleteStatus: (Long) -> Unit = {},
    onCreateGroup: (name: String, description: String, category: String, avatarUrl: String, memberIds: List<String>) -> Unit = { _, _, _, _, _ -> },
    onDeleteGroup: (String) -> Unit = {},
    onSwitchAccount: (String) -> Unit,
    onUpdateAccount: (AccountProfile) -> Unit,
    onOpenUiCustomizer: () -> Unit
) {
    // 0 = Chats, 1 = Groups, 2 = Calls, 3 = Network, 4 = Settings
    var selectedTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }
    var activeCategoryFilter by remember { mutableStateOf("All") }
    var showAccountSwitcher by remember { mutableStateOf(false) }

    // If on a sub-tab, pressing back navigates to Chats tab (0)
    BackHandler(enabled = selectedTab != 0) {
        selectedTab = 0
    }

    val activeAccount = remember(accounts, activeAccountId) {
        accounts.find { it.id == activeAccountId } ?: accounts.first()
    }

    val hasUnreadGroups = remember(groups) {
        groups.any { it.unreadCount > 0 }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "home_ambient")
    val badgePulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "badge_pulse"
    )

    LiquidAmbientBackdrop(config = uiConfig) {
        Scaffold(
            containerColor = Color.Transparent,
            floatingActionButton = {
                AnimatedVisibility(
                    visible = selectedTab == 0,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    FloatingActionButton(
                        onClick = {
                            contactsList.firstOrNull()?.let { onSelectChat(it.id) }
                        },
                        containerColor = uiConfig.primaryAccent,
                        contentColor = Color.Black,
                        shape = RoundedCornerShape(22.dp),
                        modifier = Modifier
                            .size(54.dp)
                            .border(1.dp, LiquidGlassBorderBrush, RoundedCornerShape(22.dp))
                            .testTag("fab_new_chat")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "New Chat",
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            },
            bottomBar = {
                // Floating Liquid Glass Navigation Dock
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                        .liquidGlass(
                            shape = RoundedCornerShape(32.dp),
                            backgroundColor = Color(0x380F1728),
                            borderWidth = 0.8.dp,
                            borderBrush = LiquidGlassBorderBrush
                        )
                        .padding(horizontal = 6.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val navItems = listOf(
                            NavigationItem("Chats", Icons.Default.ChatBubble, 0),
                            NavigationItem("Groups", Icons.Default.Groups, 1, badge = hasUnreadGroups),
                            NavigationItem("Calls", Icons.Default.Call, 2),
                            NavigationItem("Network", Icons.Default.Contacts, 3),
                            NavigationItem("Settings", Icons.Default.Settings, 4)
                        )

                        navItems.forEach { item ->
                            val isSelected = selectedTab == item.index
                            val itemScale by animateFloatAsState(
                                targetValue = if (isSelected) 1.1f else 1.0f,
                                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
                                label = "nav_scale_${item.index}"
                            )
                            val pillWidth by animateDpAsState(
                                targetValue = if (isSelected) 46.dp else 36.dp,
                                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                                label = "pill_width_${item.index}"
                            )

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .clickable { selectedTab = item.index }
                                    .graphicsLayer {
                                        scaleX = itemScale
                                        scaleY = itemScale
                                    }
                                    .padding(horizontal = 6.dp, vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(horizontal = 2.dp, vertical = 2.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(pillWidth)
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(
                                                if (isSelected) Brush.linearGradient(
                                                    listOf(
                                                        uiConfig.primaryAccent.copy(alpha = 0.32f),
                                                        uiConfig.secondaryAccent.copy(alpha = 0.22f)
                                                    )
                                                ) else SolidColor(Color.Transparent)
                                            )
                                            .padding(vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = item.icon,
                                            contentDescription = item.label,
                                            tint = if (isSelected) uiConfig.primaryAccent else Color(0xFF7E8EA4),
                                            modifier = Modifier.size(19.dp)
                                        )

                                        if (item.badge && !isSelected) {
                                            Box(
                                                modifier = Modifier
                                                    .align(Alignment.TopEnd)
                                                    .size(7.dp)
                                                    .graphicsLayer {
                                                        scaleX = badgePulse
                                                        scaleY = badgePulse
                                                    }
                                                    .clip(CircleShape)
                                                    .background(uiConfig.primaryAccent)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = item.label,
                                        color = if (isSelected) Color.White else Color(0xFF6E7E95),
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .statusBarsPadding()
            ) {
                AnimatedContent(
                    targetState = selectedTab,
                    transitionSpec = {
                        if (targetState > initialState) {
                            (slideInHorizontally(animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioLowBouncy)) { width -> width / 3 } + fadeIn())
                                .togetherWith(slideOutHorizontally(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) { width -> -width / 3 } + fadeOut())
                        } else {
                            (slideInHorizontally(animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioLowBouncy)) { width -> -width / 3 } + fadeIn())
                                .togetherWith(slideOutHorizontally(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) { width -> width / 3 } + fadeOut())
                        }
                    },
                    label = "home_tab_transition"
                ) { currentTab ->
                    when (currentTab) {
                        0 -> LiquidChatsContent(
                            chats = chats,
                            contactsMap = contactsMap,
                            contactsList = contactsList,
                            statuses = statuses,
                            searchQuery = searchQuery,
                            onSearchChange = { searchQuery = it },
                            isSearchActive = isSearchActive,
                            onToggleSearch = { isSearchActive = !isSearchActive },
                            activeFilter = activeCategoryFilter,
                            onFilterChange = { activeCategoryFilter = it },
                            onSelectChat = onSelectChat,
                            onPostStatus = onPostStatus,
                            onMarkStatusViewed = onMarkStatusViewed,
                            onDeleteStatus = onDeleteStatus,
                            activeAccount = activeAccount,
                            uiConfig = uiConfig,
                            onOpenAccountSwitcher = { showAccountSwitcher = true },
                            onOpenUiCustomizer = onOpenUiCustomizer
                        )
                        1 -> GroupsScreen(
                            groups = groups,
                            contactsMap = contactsMap,
                            contactsList = contactsList,
                            uiConfig = uiConfig,
                            onSelectGroup = onSelectChat,
                            onCreateGroup = onCreateGroup,
                            onDeleteGroup = onDeleteGroup
                        )
                        2 -> CallLogsScreen(
                            callLogs = callLogs,
                            contactsMap = contactsMap,
                            onStartCall = onStartCall
                        )
                        3 -> ContactsScreen(
                            contacts = contactsList,
                            onSelectChat = onSelectChat,
                            onStartCall = onStartCall
                        )
                        4 -> SettingsScreen(
                            activeAccount = activeAccount,
                            uiConfig = uiConfig,
                            onOpenAccountSwitcher = { showAccountSwitcher = true },
                            onOpenUiCustomizer = onOpenUiCustomizer
                        )
                    }
                }
            }
        }

        if (showAccountSwitcher) {
            AccountSwitcherSheet(
                accounts = accounts,
                activeAccountId = activeAccountId,
                onSelectAccount = onSwitchAccount,
                onUpdateAccount = onUpdateAccount,
                onDismiss = { showAccountSwitcher = false }
            )
        }
    }
}

data class NavigationItem(
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val index: Int,
    val badge: Boolean = false
)

@Composable
fun LiquidChatsContent(
    chats: List<ChatEntity>,
    contactsMap: Map<String, ContactEntity>,
    contactsList: List<ContactEntity>,
    statuses: List<StatusEntity> = emptyList(),
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    isSearchActive: Boolean,
    onToggleSearch: () -> Unit,
    activeFilter: String,
    onFilterChange: (String) -> Unit,
    onSelectChat: (String) -> Unit,
    onPostStatus: (String, String?, Int) -> Unit = { _, _, _ -> },
    onMarkStatusViewed: (Long) -> Unit = {},
    onDeleteStatus: (Long) -> Unit = {},
    activeAccount: AccountProfile,
    uiConfig: UiCustomizationConfig,
    onOpenAccountSwitcher: () -> Unit,
    onOpenUiCustomizer: () -> Unit
) {
    var activeStatusViewerIndex by remember { mutableStateOf<Int?>(null) }
    var showStatusComposer by remember { mutableStateOf(false) }

    val myStatus = remember(statuses) { statuses.find { it.contactId == "me" } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("chats_tab_content")
    ) {
        // Pure Liquid Glass Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .liquidGlass(
                    shape = RoundedCornerShape(26.dp),
                    backgroundColor = Color(0x2E121B2F),
                    borderWidth = 0.8.dp,
                    borderBrush = LiquidGlassBorderBrush
                )
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Profile Switcher Trigger
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .clickable { onOpenAccountSwitcher() }
                            .testTag("top_bar_account_switcher_trigger")
                    ) {
                        Box(modifier = Modifier.size(42.dp)) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .border(1.5.dp, uiConfig.primaryAccent, CircleShape)
                                    .padding(1.5.dp)
                            ) {
                                AsyncImage(
                                    model = activeAccount.avatarUrl,
                                    contentDescription = activeAccount.displayName,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(uiConfig.primaryAccent)
                                    .border(1.2.dp, Color(0xFF090D18), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SwapHoriz,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(10.dp)
                                )
                            }
                        }

                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "LiquidChat",
                                    color = Color.White,
                                    fontSize = 19.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.3.sp
                                )
                                LosslessBadge(text = "E2EE")
                            }
                            Text(
                                text = "${activeAccount.displayName} • Switch Account",
                                color = uiConfig.primaryAccent,
                                fontSize = 10.5.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Action buttons: UI Studio + Search
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(
                            onClick = onOpenUiCustomizer,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0x1AFFFFFF))
                                .testTag("top_bar_open_customizer_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Palette,
                                contentDescription = "UI Studio",
                                tint = uiConfig.primaryAccent,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = onToggleSearch,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0x1AFFFFFF))
                                .testTag("top_bar_search_button")
                        ) {
                            Icon(
                                imageVector = if (isSearchActive) Icons.Default.Close else Icons.Default.Search,
                                contentDescription = "Search",
                                tint = if (isSearchActive) uiConfig.primaryAccent else Color.White,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }

                // Smooth expandable search field
                AnimatedVisibility(
                    visible = isSearchActive,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp)
                            .liquidPill(backgroundColor = Color(0x33101828))
                            .padding(horizontal = 12.dp, vertical = 2.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = onSearchChange,
                            placeholder = {
                                Text(
                                    text = "Search messages & contacts...",
                                    color = Color(0xFF7A8C9E),
                                    fontSize = 12.5.sp
                                )
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                cursorColor = LiquidCyan
                            ),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }
            }
        }

        // WhatsApp-style Status / Stories Ribbon
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            contentPadding = PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // "My Status" entry in stories bar
            item {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable {
                        if (myStatus != null) {
                            val idx = statuses.indexOf(myStatus)
                            activeStatusViewerIndex = if (idx >= 0) idx else null
                        } else {
                            showStatusComposer = true
                        }
                    }
                ) {
                    Box(modifier = Modifier.size(52.dp)) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .border(
                                    1.5.dp,
                                    if (myStatus != null) Brush.linearGradient(listOf(uiConfig.primaryAccent, uiConfig.secondaryAccent))
                                    else Brush.linearGradient(listOf(Color(0x44FFFFFF), Color(0x18FFFFFF))),
                                    CircleShape
                                )
                                .padding(2.dp)
                        ) {
                            AsyncImage(
                                model = activeAccount.avatarUrl,
                                contentDescription = "Add Status",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(uiConfig.primaryAccent)
                                .border(1.5.dp, Color(0xFF080B14), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(10.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (myStatus != null) "My Status" else "Add Status",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Contacts Stories
            items(contactsList, key = { it.id }) { contact ->
                val contactStatus = statuses.find { it.contactId == contact.id }
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable {
                            if (contactStatus != null) {
                                val idx = statuses.indexOf(contactStatus)
                                if (idx >= 0) activeStatusViewerIndex = idx
                            } else {
                                onSelectChat(contact.id)
                            }
                        }
                        .testTag("presence_avatar_${contact.id}")
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .border(
                                2.dp,
                                if (contactStatus != null && !contactStatus.isViewed) Brush.linearGradient(listOf(uiConfig.primaryAccent, uiConfig.secondaryAccent))
                                else if (contact.isOnline) Brush.linearGradient(listOf(LiquidCyan, LiquidViolet))
                                else Brush.linearGradient(listOf(Color(0x33FFFFFF), Color(0x11FFFFFF))),
                                CircleShape
                            )
                            .padding(2.dp)
                    ) {
                        AsyncImage(
                            model = contact.avatarUrl,
                            contentDescription = contact.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = contact.name.split(" ").firstOrNull() ?: contact.name,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // Clean Category Filter Pills
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            contentPadding = PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val filters = listOf("All", "Unread", "Lossless Media", "Encrypted")
            items(filters) { filter ->
                val isSelected = activeFilter == filter
                val chipScale by animateFloatAsState(
                    targetValue = if (isSelected) 1.04f else 1.0f,
                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
                    label = "chip_scale_$filter"
                )
                Box(
                    modifier = Modifier
                        .graphicsLayer {
                            scaleX = chipScale
                            scaleY = chipScale
                        }
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            if (isSelected) Brush.linearGradient(
                                listOf(uiConfig.primaryAccent, uiConfig.secondaryAccent)
                            )
                            else SolidColor(Color(0x22162540))
                        )
                        .border(
                            0.8.dp,
                            if (isSelected) uiConfig.primaryAccent else Color(0x1AFFFFFF),
                            RoundedCornerShape(14.dp)
                        )
                        .clickable { onFilterChange(filter) }
                        .padding(horizontal = 12.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = filter,
                        color = if (isSelected) Color.Black else Color(0xFFBACADC),
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        // Filtered Chats
        val filteredChats = chats.filter { chat ->
            val contact = contactsMap[chat.contactId]
            val matchesQuery = searchQuery.isBlank() ||
                (contact?.name?.contains(searchQuery, ignoreCase = true) == true) ||
                chat.lastMessage.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (activeFilter) {
                "Unread" -> chat.unreadCount > 0
                "Lossless Media" -> chat.lastMessage.contains("RAW", ignoreCase = true) ||
                    chat.lastMessage.contains("4K", ignoreCase = true) ||
                    chat.lastMessage.contains("Lossless", ignoreCase = true) ||
                    chat.lastMessage.contains("Voice", ignoreCase = true)
                else -> true
            }

            matchesQuery && matchesFilter
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredChats, key = { it.id }) { chat ->
                val contact = contactsMap[chat.contactId]
                val contactName = contact?.name ?: "Unknown Contact"
                val avatarUrl = contact?.avatarUrl ?: ""
                val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(chat.lastMessageTime))

                Row(
                    modifier = Modifier
                        .animateItem()
                        .fillMaxWidth()
                        .liquidGlass(
                            shape = RoundedCornerShape(22.dp),
                            backgroundColor = Color(0x2814233C),
                            borderWidth = 0.8.dp,
                            borderBrush = LiquidGlassBorderBrush
                        )
                        .clickable { onSelectChat(chat.id) }
                        .padding(12.dp)
                        .testTag("chat_item_${chat.id}"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Contact Avatar with liquid border & online dot
                    Box(modifier = Modifier.size(50.dp)) {
                        AsyncImage(
                            model = avatarUrl,
                            contentDescription = contactName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .border(1.2.dp, LiquidGlassBorderBrush, CircleShape)
                        )

                        if (contact?.isOnline == true) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(LiquidEmerald)
                                    .border(2.dp, Color(0xFF080B14), CircleShape)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Message Details
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = contactName,
                                    color = Color.White,
                                    fontSize = 14.5.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Encrypted",
                                    tint = LiquidCyan,
                                    modifier = Modifier.size(11.dp)
                                )
                            }

                            Text(
                                text = timeStr,
                                color = if (chat.unreadCount > 0) LiquidCyan else Color(0xFF7E8EA4),
                                fontSize = 10.5.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (chat.unreadCount > 0) FontWeight.Bold else FontWeight.Normal
                            )
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = chat.lastMessage,
                                color = if (chat.unreadCount > 0) Color.White else Color(0xFF9FB2CA),
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )

                            if (chat.unreadCount > 0) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(LiquidCyan)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${chat.unreadCount}",
                                        color = Color.Black,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        activeStatusViewerIndex?.let { idx ->
            val currentStatus = statuses.getOrNull(idx)
            if (currentStatus != null) {
                onMarkStatusViewed(currentStatus.id)
                StatusViewerDialog(
                    status = currentStatus,
                    onDismiss = { activeStatusViewerIndex = null },
                    onNext = {
                        if (idx < statuses.size - 1) activeStatusViewerIndex = idx + 1
                        else activeStatusViewerIndex = null
                    },
                    onPrevious = {
                        if (idx > 0) activeStatusViewerIndex = idx - 1
                    },
                    onReply = { reply ->
                        onSelectChat(currentStatus.contactId)
                        activeStatusViewerIndex = null
                    },
                    onDelete = if (currentStatus.contactId == "me") {
                        {
                            onDeleteStatus(currentStatus.id)
                            activeStatusViewerIndex = null
                        }
                    } else null
                )
            }
        }

        if (showStatusComposer) {
            NewStatusComposerDialog(
                onDismiss = { showStatusComposer = false },
                onPostStatus = { text, media, grad ->
                    onPostStatus(text, media, grad)
                    showStatusComposer = false
                }
            )
        }
    }
}
