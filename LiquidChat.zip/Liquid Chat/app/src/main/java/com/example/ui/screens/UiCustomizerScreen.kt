package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Opacity
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.RoundedCorner
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AvailableColorPresets
import com.example.data.model.BackdropTheme
import com.example.data.model.BubbleStyle
import com.example.data.model.PartnerBubbleStyle
import com.example.data.model.UiCustomizationConfig
import com.example.ui.components.LosslessBadge
import com.example.ui.components.liquidGlass
import com.example.ui.components.liquidPill
import com.example.ui.theme.LiquidCyan
import com.example.ui.theme.LiquidGlassBorder
import com.example.ui.theme.LiquidGlassBorderBrush

@Composable
fun UiCustomizerScreen(
    config: UiCustomizationConfig,
    onUpdateConfig: (UiCustomizationConfig) -> Unit,
    onResetConfig: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler {
        onBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("ui_customizer_screen")
    ) {
        // Top Navigation Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .liquidGlass(
                    shape = RoundedCornerShape(26.dp),
                    backgroundColor = Color(0x35121B2F),
                    borderBrush = LiquidGlassBorderBrush
                )
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    Column {
                        Text(
                            text = "UI & Chat Studio",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Liquid Glass & Chat Appearance",
                            color = config.primaryAccent,
                            fontSize = 10.5.sp
                        )
                    }
                }

                // Reset Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x22FFFFFF))
                        .clickable { onResetConfig() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("reset_ui_customizer_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = "Reset",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Reset",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Scrollable Customizer Body
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Interactive Preview
            LiveChatPreviewCard(config = config)

            // 1. Accent Color Palette
            CustomizerSection(
                title = "LIQUID ACCENT THEME",
                icon = Icons.Default.Palette
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    AvailableColorPresets.forEach { preset ->
                        val isSelected = config.primaryAccentHex == preset.primary
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    onUpdateConfig(
                                        config.copy(
                                            primaryAccentHex = preset.primary,
                                            secondaryAccentHex = preset.secondary
                                        )
                                    )
                                }
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                .testTag("color_preset_${preset.id}")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            listOf(Color(preset.primary), Color(preset.secondary))
                                        )
                                    )
                                    .border(
                                        if (isSelected) 2.5.dp else 1.dp,
                                        if (isSelected) Color.White else Color(0x33FFFFFF),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = Color.Black,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = preset.name,
                                color = if (isSelected) Color.White else Color(0xFF8B9FB8),
                                fontSize = 9.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            // 2. Glass Opacity & Specular Highlight Sliders
            CustomizerSection(
                title = "LIQUID FROSTING & SPECULAR REFLECTION",
                icon = Icons.Default.Opacity
            ) {
                // Frosting Opacity
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Glass Frosting Opacity", color = Color.White, fontSize = 12.5.sp)
                        Text(
                            text = "${(config.glassOpacity * 100).toInt()}%",
                            color = config.primaryAccent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Slider(
                        value = config.glassOpacity,
                        onValueChange = { onUpdateConfig(config.copy(glassOpacity = it)) },
                        valueRange = 0.12f..0.60f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = config.primaryAccent,
                            inactiveTrackColor = Color(0x33FFFFFF)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Specular Edge Reflection
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Specular Edge Intensity", color = Color.White, fontSize = 12.5.sp)
                        Text(
                            text = "${(config.specularBorderAlpha * 100).toInt()}%",
                            color = config.primaryAccent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Slider(
                        value = config.specularBorderAlpha,
                        onValueChange = { onUpdateConfig(config.copy(specularBorderAlpha = it)) },
                        valueRange = 0.15f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = config.primaryAccent,
                            inactiveTrackColor = Color(0x33FFFFFF)
                        )
                    )
                }
            }

            // 3. Corner Curvature
            CustomizerSection(
                title = "CORNER CURVATURE",
                icon = Icons.Default.RoundedCorner
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val corners = listOf(14 to "Sleek (14dp)", 20 to "Smooth (20dp)", 28 to "Extra Fluid (28dp)")
                    corners.forEach { (radius, label) ->
                        val isSelected = config.cornerRadiusDp == radius
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) config.primaryAccent else Color(0x22182844))
                                .border(
                                    1.dp,
                                    if (isSelected) config.primaryAccent else Color(0x22FFFFFF),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { onUpdateConfig(config.copy(cornerRadiusDp = radius)) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (isSelected) Color.Black else Color.White,
                                fontSize = 10.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // 4. Chat Wallpaper / Liquid Backdrop
            CustomizerSection(
                title = "LIQUID WALLPAPER BACKDROP",
                icon = Icons.Default.Wallpaper
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    BackdropTheme.entries.forEach { theme ->
                        val isSelected = config.backdropTheme == theme
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isSelected) Color(0x350A58D0) else Color(0x1F162640))
                                .border(
                                    1.dp,
                                    if (isSelected) config.primaryAccent else Color(0x1AFFFFFF),
                                    RoundedCornerShape(14.dp)
                                )
                                .clickable { onUpdateConfig(config.copy(backdropTheme = theme)) }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = theme.label,
                                color = Color.White,
                                fontSize = 12.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )

                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = config.primaryAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 5. My Chat Bubble Style
            CustomizerSection(
                title = "OUTGOING CHAT BUBBLE STYLE",
                icon = Icons.Default.Layers
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    BubbleStyle.entries.forEach { style ->
                        val isSelected = config.bubbleStyle == style
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isSelected) Color(0x350A58D0) else Color(0x1F162640))
                                .border(
                                    1.dp,
                                    if (isSelected) config.primaryAccent else Color(0x1AFFFFFF),
                                    RoundedCornerShape(14.dp)
                                )
                                .clickable { onUpdateConfig(config.copy(bubbleStyle = style)) }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = style.label,
                                color = Color.White,
                                fontSize = 12.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )

                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = config.primaryAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 6. Incoming (Partner) Bubble Style
            CustomizerSection(
                title = "INCOMING PARTNER BUBBLE STYLE",
                icon = Icons.Default.Layers
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PartnerBubbleStyle.entries.forEach { style ->
                        val isSelected = config.partnerBubbleStyle == style
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isSelected) Color(0x350A58D0) else Color(0x1F162640))
                                .border(
                                    1.dp,
                                    if (isSelected) config.primaryAccent else Color(0x1AFFFFFF),
                                    RoundedCornerShape(14.dp)
                                )
                                .clickable { onUpdateConfig(config.copy(partnerBubbleStyle = style)) }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = style.label,
                                color = Color.White,
                                fontSize = 12.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )

                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = config.primaryAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 7. Typography Scale & Toggles
            CustomizerSection(
                title = "TEXT SCALE & INDICATORS",
                icon = Icons.Default.FormatSize
            ) {
                // Font Size
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val sizes = listOf(13 to "Compact (13sp)", 15 to "Standard (15sp)", 17 to "Large (17sp)")
                    sizes.forEach { (size, label) ->
                        val isSelected = config.chatFontSizeSp == size
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) config.primaryAccent else Color(0x22182844))
                                .border(
                                    1.dp,
                                    if (isSelected) config.primaryAccent else Color(0x22FFFFFF),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { onUpdateConfig(config.copy(chatFontSizeSp = size)) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (isSelected) Color.Black else Color.White,
                                fontSize = 10.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Toggles
                CustomizerToggleRow(
                    title = "Show Lossless 💎 Badges",
                    checked = config.showLosslessBadges,
                    accentColor = config.primaryAccent,
                    onCheckedChange = { onUpdateConfig(config.copy(showLosslessBadges = it)) }
                )

                Spacer(modifier = Modifier.height(8.dp))

                CustomizerToggleRow(
                    title = "Show Message Timestamps",
                    checked = config.showTimestamps,
                    accentColor = config.primaryAccent,
                    onCheckedChange = { onUpdateConfig(config.copy(showTimestamps = it)) }
                )

                Spacer(modifier = Modifier.height(8.dp))

                CustomizerToggleRow(
                    title = "Dynamic Ambient Shimmer Mesh",
                    checked = config.enableDynamicOrbs,
                    accentColor = config.primaryAccent,
                    onCheckedChange = { onUpdateConfig(config.copy(enableDynamicOrbs = it)) }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun LiveChatPreviewCard(config: UiCustomizationConfig) {
    Column {
        Text(
            text = "LIVE INTERACTIVE PREVIEW",
            color = config.primaryAccent,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp,
            modifier = Modifier.padding(start = 6.dp, bottom = 6.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .liquidGlass(
                    shape = RoundedCornerShape(config.cornerRadiusDp.dp),
                    backgroundColor = Color(0x350F182C),
                    borderBrush = Brush.linearGradient(
                        listOf(
                            Color.White.copy(alpha = config.specularBorderAlpha),
                            Color.White.copy(alpha = 0.1f)
                        )
                    )
                )
                .padding(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Incoming message preview
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.82f)
                            .clip(
                                RoundedCornerShape(
                                    topStart = config.cornerRadiusDp.dp,
                                    topEnd = config.cornerRadiusDp.dp,
                                    bottomStart = 4.dp,
                                    bottomEnd = config.cornerRadiusDp.dp
                                )
                            )
                            .background(config.getPartnerBubbleBrush())
                            .border(
                                1.dp,
                                Brush.linearGradient(
                                    listOf(
                                        Color.White.copy(alpha = config.specularBorderAlpha * 0.7f),
                                        Color(0x10FFFFFF)
                                    )
                                ),
                                RoundedCornerShape(
                                    topStart = config.cornerRadiusDp.dp,
                                    topEnd = config.cornerRadiusDp.dp,
                                    bottomStart = 4.dp,
                                    bottomEnd = config.cornerRadiusDp.dp
                                )
                            )
                            .padding(10.dp)
                    ) {
                        Column {
                            Text(
                                text = "Liquid Glass iOS 26 optics look pristine! Notice the live refraction depth.",
                                color = Color.White,
                                fontSize = config.chatFontSizeSp.sp,
                                lineHeight = (config.chatFontSizeSp + 5).sp
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            if (config.showTimestamps) {
                                Row(
                                    modifier = Modifier.align(Alignment.End),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    if (config.showLosslessBadges) {
                                        Text("RAW", color = config.primaryAccent, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text("10:42", color = Color(0xFF8697AF), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }

                // Outgoing message preview
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.78f)
                            .clip(
                                RoundedCornerShape(
                                    topStart = config.cornerRadiusDp.dp,
                                    topEnd = config.cornerRadiusDp.dp,
                                    bottomStart = config.cornerRadiusDp.dp,
                                    bottomEnd = 4.dp
                                )
                            )
                            .background(config.getMyBubbleBrush())
                            .border(
                                1.dp,
                                Brush.linearGradient(
                                    listOf(
                                        Color.White.copy(alpha = config.specularBorderAlpha),
                                        Color.Transparent
                                    )
                                ),
                                RoundedCornerShape(
                                    topStart = config.cornerRadiusDp.dp,
                                    topEnd = config.cornerRadiusDp.dp,
                                    bottomStart = config.cornerRadiusDp.dp,
                                    bottomEnd = 4.dp
                                )
                            )
                            .padding(10.dp)
                    ) {
                        Column {
                            Text(
                                text = "Every color, opacity, and bubble radius updates instantaneously ✨",
                                color = Color.White,
                                fontSize = config.chatFontSizeSp.sp,
                                lineHeight = (config.chatFontSizeSp + 5).sp
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            if (config.showTimestamps) {
                                Row(
                                    modifier = Modifier.align(Alignment.End),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    if (config.showLosslessBadges) {
                                        Text("LOSSLESS", color = Color.White, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text("10:43", color = Color(0xCCFFFFFF), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CustomizerSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit
) {
    Column {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(start = 6.dp, bottom = 6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFFA5B8D4),
                modifier = Modifier.size(13.dp)
            )
            Text(
                text = title,
                color = Color(0xFFA5B8D4),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .liquidGlass(
                    shape = RoundedCornerShape(20.dp),
                    backgroundColor = Color(0x28131E33),
                    borderBrush = LiquidGlassBorderBrush
                )
                .padding(14.dp)
        ) {
            Column {
                content()
            }
        }
    }
}

@Composable
fun CustomizerToggleRow(
    title: String,
    checked: Boolean,
    accentColor: Color,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, color = Color.White, fontSize = 12.5.sp)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = accentColor,
                uncheckedThumbColor = Color(0xFFBACADC),
                uncheckedTrackColor = Color(0x33FFFFFF)
            )
        )
    }
}
