package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.LosslessBadge
import com.example.ui.components.liquidGlass
import com.example.ui.theme.LiquidCyan
import com.example.ui.theme.LiquidEmerald
import com.example.ui.theme.LiquidGlassBorder
import com.example.ui.theme.LiquidGlassBorderBrush
import com.example.ui.theme.LiquidMagenta
import com.example.ui.theme.LiquidViolet

import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.SwapHoriz
import coil.compose.AsyncImage
import com.example.data.model.AccountProfile
import com.example.data.model.UiCustomizationConfig

@Composable
fun SettingsScreen(
    activeAccount: AccountProfile? = null,
    uiConfig: UiCustomizationConfig? = null,
    onOpenAccountSwitcher: () -> Unit = {},
    onOpenUiCustomizer: () -> Unit = {}
) {
    var losslessPhotos by remember { mutableStateOf(true) }
    var lossless4kVideo by remember { mutableStateOf(true) }
    var studioAudio48k by remember { mutableStateOf(true) }
    var hardwareEnclaveE2EE by remember { mutableStateOf(true) }
    var dynamicLiquidRefraction by remember { mutableStateOf(true) }
    var globalMeshRouting by remember { mutableStateOf(true) }

    val accent = uiConfig?.primaryAccent ?: LiquidCyan

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("settings_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .liquidGlass(
                    shape = RoundedCornerShape(22.dp),
                    backgroundColor = Color(0x33121B2F),
                    borderBrush = LiquidGlassBorderBrush
                )
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Liquid Engine Settings",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "iOS 26 Liquid Glass & Cryptographic Bitstream",
                        color = accent,
                        fontSize = 11.5.sp
                    )
                }

                LosslessBadge(text = "PRO SYSTEM")
            }
        }

        // Active Account & Switcher Card (User can add/switch 2 accounts)
        if (activeAccount != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlass(
                        shape = RoundedCornerShape(22.dp),
                        backgroundColor = Color(0x350F1A2D),
                        borderBrush = LiquidGlassBorderBrush
                    )
                    .clickable { onOpenAccountSwitcher() }
                    .padding(14.dp)
                    .testTag("settings_account_card")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, accent, CircleShape)
                            .padding(2.dp)
                    ) {
                        AsyncImage(
                            model = activeAccount.avatarUrl,
                            contentDescription = activeAccount.displayName,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = activeAccount.displayName,
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0x3300F5A0))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("ACTIVE", color = LiquidEmerald, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(
                            text = "${activeAccount.handle} • ${activeAccount.phoneNumber}",
                            color = Color(0xFFA5B8D4),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Tap to switch between 2 accounts",
                            color = accent,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0x22FFFFFF))
                            .border(1.dp, LiquidGlassBorder, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = "Switch Account",
                            tint = accent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // Full UI & Chat Customizer Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .liquidGlass(
                    shape = RoundedCornerShape(22.dp),
                    backgroundColor = Color(0x35142138),
                    borderBrush = LiquidGlassBorderBrush
                )
                .clickable { onOpenUiCustomizer() }
                .padding(14.dp)
                .testTag("settings_open_ui_customizer_card")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(accent, LiquidViolet)))
                        .border(1.dp, LiquidGlassBorderBrush, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Palette,
                        contentDescription = "UI Customizer",
                        tint = Color.Black,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Full UI & Chat Studio",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Customize colors, glass frosting, bubbles, curvature & wallpaper",
                        color = Color(0xFFA5B8D4),
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x2800F2FE))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "CUSTOMIZE",
                        color = accent,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Section: Lossless Quality
        SettingsSection(title = "LOSSLESS BITSTREAM TRANSMISSION") {
            SettingsToggleRow(
                icon = Icons.Default.Diamond,
                iconTint = LiquidCyan,
                title = "Original RAW Photo Sharing",
                subtitle = "Preserve 100% EXIF, DNG 48MP, 0% JPEG compression",
                checked = losslessPhotos,
                onCheckedChange = { losslessPhotos = it }
            )

            Spacer(modifier = Modifier.height(8.dp))

            SettingsToggleRow(
                icon = Icons.Default.AutoAwesome,
                iconTint = LiquidMagenta,
                title = "4K 60fps ProRes Video Stream",
                subtitle = "Bit-exact transfers without cloud re-encoding",
                checked = lossless4kVideo,
                onCheckedChange = { lossless4kVideo = it }
            )

            Spacer(modifier = Modifier.height(8.dp))

            SettingsToggleRow(
                icon = Icons.Default.Tune,
                iconTint = LiquidViolet,
                title = "48kHz Opus Studio Audio",
                subtitle = "Uncompressed voice calls & voice messages",
                checked = studioAudio48k,
                onCheckedChange = { studioAudio48k = it }
            )
        }

        // Section: Cryptography & Security
        SettingsSection(title = "END-TO-END ENCRYPTION (E2EE)") {
            SettingsToggleRow(
                icon = Icons.Default.Shield,
                iconTint = LiquidEmerald,
                title = "Hardware Enclave Ratchet v4",
                subtitle = "AES-256-GCM + X3DH key agreement per packet",
                checked = hardwareEnclaveE2EE,
                onCheckedChange = { hardwareEnclaveE2EE = it }
            )

            Spacer(modifier = Modifier.height(8.dp))

            SettingsToggleRow(
                icon = Icons.Default.NetworkCheck,
                iconTint = LiquidCyan,
                title = "Global Onion Mesh Relays",
                subtitle = "Multi-hop routing through Zurich, Tokyo & Singapore",
                checked = globalMeshRouting,
                onCheckedChange = { globalMeshRouting = it }
            )
        }

        // Section: iOS 26 Liquid Glass Display
        SettingsSection(title = "LIQUID GLASS AESTHETIC") {
            SettingsToggleRow(
                icon = Icons.Default.Fingerprint,
                iconTint = Color(0xFFFF9500),
                title = "Fluid Refraction & Specular Bloom",
                subtitle = "Interactive 60fps ambient glowing mesh rendering",
                checked = dynamicLiquidRefraction,
                onCheckedChange = { dynamicLiquidRefraction = it }
            )
        }

        // App Version Pill
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "LiquidChat v26.4.0 (Build 9042)",
                    color = Color(0xFF8E9EB8),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Liquid Glass • Global E2EE • Bit-exact Lossless Media",
                    color = LiquidCyan.copy(alpha = 0.7f),
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
fun SettingsSection(
    title: String,
    content: @Composable () -> Unit
) {
    Column {
        Text(
            text = title,
            color = Color(0xFFA0B3D1),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp,
            modifier = Modifier.padding(start = 8.dp, bottom = 6.dp)
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .liquidGlass(
                    shape = RoundedCornerShape(20.dp),
                    backgroundColor = Color(0x2D162540),
                    borderBrush = LiquidGlassBorderBrush
                )
                .padding(14.dp)
        ) {
            Column {
                content()
            }
        }
    }
}

@Composable
fun SettingsToggleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(Color(0x22FFFFFF))
                .border(1.dp, LiquidGlassBorder, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                color = Color(0xFF9CB0CD),
                fontSize = 10.5.sp
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = LiquidCyan,
                uncheckedThumbColor = Color(0xFFBACADF),
                uncheckedTrackColor = Color(0x33FFFFFF)
            )
        )
    }
}
