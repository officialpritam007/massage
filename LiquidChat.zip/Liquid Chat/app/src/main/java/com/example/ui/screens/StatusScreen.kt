package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.StatusEntity
import com.example.ui.components.LosslessBadge
import com.example.ui.components.liquidGlass
import com.example.ui.components.liquidPill
import com.example.ui.theme.LiquidCyan
import com.example.ui.theme.LiquidEmerald
import com.example.ui.theme.LiquidGlassBorder
import com.example.ui.theme.LiquidGlassBorderBrush
import com.example.ui.theme.LiquidViolet
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatusScreen(
    statuses: List<StatusEntity>,
    uiConfig: com.example.data.model.UiCustomizationConfig = com.example.data.model.UiCustomizationConfig(),
    onPostStatus: (String, String?, Int) -> Unit,
    onMarkStatusViewed: (Long) -> Unit,
    onDeleteStatus: (Long) -> Unit = {},
    onReplyToStatus: (String, String) -> Unit
) {
    var showComposer by remember { mutableStateOf(false) }
    var activeViewingStatusIndex by remember { mutableIntStateOf(-1) }

    val myStatus = statuses.firstOrNull { it.contactId == "me" }
    val otherStatuses = statuses.filter { it.contactId != "me" }
    val recentStatuses = otherStatuses.filter { !it.isViewed }
    val viewedStatuses = otherStatuses.filter { it.isViewed }

    Scaffold(
        containerColor = Color.Transparent,
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Secondary Text Status FAB
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .liquidPill(backgroundColor = Color(0x35142138))
                        .clickable { showComposer = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Text Status",
                        tint = uiConfig.primaryAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Primary Camera/Media Status FAB
                FloatingActionButton(
                    onClick = { showComposer = true },
                    containerColor = uiConfig.primaryAccent,
                    contentColor = Color.Black,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .size(54.dp)
                        .border(1.dp, LiquidGlassBorderBrush, RoundedCornerShape(20.dp))
                        .testTag("fab_add_status")
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoCamera,
                        contentDescription = "New Status",
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .testTag("status_screen"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .liquidGlass(
                            shape = RoundedCornerShape(22.dp),
                            backgroundColor = Color(0x33121B2F),
                            borderBrush = LiquidGlassBorderBrush
                        )
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Liquid Status",
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Disappears after 24 hours • E2EE Encrypted",
                                color = LiquidCyan,
                                fontSize = 11.sp
                            )
                        }

                        LosslessBadge(text = "LIVE MESH")
                    }
                }
            }

            // My Status Item
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .liquidGlass(
                            shape = RoundedCornerShape(22.dp),
                            backgroundColor = Color(0x2E16243D),
                            borderBrush = LiquidGlassBorderBrush
                        )
                        .clickable {
                            if (myStatus != null) {
                                activeViewingStatusIndex = statuses.indexOf(myStatus)
                            } else {
                                showComposer = true
                            }
                        }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Avatar with "+" badge or active ring
                    Box(modifier = Modifier.size(54.dp)) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .border(
                                    1.5.dp,
                                    if (myStatus != null) Brush.linearGradient(listOf(LiquidCyan, LiquidViolet))
                                    else Brush.linearGradient(listOf(Color(0x33FFFFFF), Color(0x11FFFFFF))),
                                    CircleShape
                                )
                                .padding(2.dp)
                        ) {
                            AsyncImage(
                                model = myStatus?.authorAvatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80",
                                contentDescription = "My Status",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                            )
                        }

                        if (myStatus == null) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(LiquidCyan)
                                    .border(1.5.dp, Color(0xFF080B14), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Add Status",
                                    tint = Color.Black,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "My Status",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (myStatus != null) {
                                val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(myStatus.timestamp))
                                "$time • ${myStatus.viewsCount} views"
                            } else {
                                "Tap to add status update"
                            },
                            color = if (myStatus != null) LiquidCyan else Color(0xFF90A3BE),
                            fontSize = 11.5.sp
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = { showComposer = true },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0x22FFFFFF))
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhotoCamera,
                                contentDescription = "Camera",
                                tint = Color.White,
                                modifier = Modifier.size(17.dp)
                            )
                        }

                        IconButton(
                            onClick = { showComposer = true },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0x22FFFFFF))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Text",
                                tint = LiquidCyan,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }
            }

            // Recent Updates Section
            if (recentStatuses.isNotEmpty()) {
                item {
                    Text(
                        text = "RECENT UPDATES",
                        color = Color(0xFFA0B3D1),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp,
                        modifier = Modifier.padding(start = 6.dp, top = 6.dp)
                    )
                }

                items(recentStatuses, key = { it.id }) { item ->
                    StatusRowItem(
                        status = item,
                        isViewed = false,
                        onClick = {
                            activeViewingStatusIndex = statuses.indexOf(item)
                            onMarkStatusViewed(item.id)
                        }
                    )
                }
            }

            // Viewed Updates Section
            if (viewedStatuses.isNotEmpty()) {
                item {
                    Text(
                        text = "VIEWED UPDATES",
                        color = Color(0xFF7A8B9F),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp,
                        modifier = Modifier.padding(start = 6.dp, top = 6.dp)
                    )
                }

                items(viewedStatuses, key = { it.id }) { item ->
                    StatusRowItem(
                        status = item,
                        isViewed = true,
                        onClick = {
                            activeViewingStatusIndex = statuses.indexOf(item)
                            onMarkStatusViewed(item.id)
                        }
                    )
                }
            }
        }
    }

    // Active Status Viewer Dialog
    if (activeViewingStatusIndex >= 0 && activeViewingStatusIndex < statuses.size) {
        val currentStatus = statuses[activeViewingStatusIndex]
        StatusViewerDialog(
            status = currentStatus,
            onDismiss = { activeViewingStatusIndex = -1 },
            onNext = {
                if (activeViewingStatusIndex < statuses.size - 1) {
                    activeViewingStatusIndex++
                    onMarkStatusViewed(statuses[activeViewingStatusIndex].id)
                } else {
                    activeViewingStatusIndex = -1
                }
            },
            onPrevious = {
                if (activeViewingStatusIndex > 0) {
                    activeViewingStatusIndex--
                }
            },
            onReply = { message ->
                onReplyToStatus(currentStatus.contactId, "Replying to status: $message")
            },
            onDelete = {
                onDeleteStatus(currentStatus.id)
                activeViewingStatusIndex = -1
            }
        )
    }

    // New Status Composer Dialog
    if (showComposer) {
        NewStatusComposerDialog(
            onDismiss = { showComposer = false },
            onPostStatus = { caption, mediaUrl, gradientIndex ->
                onPostStatus(caption, mediaUrl, gradientIndex)
            }
        )
    }
}

@Composable
fun StatusRowItem(
    status: StatusEntity,
    isViewed: Boolean,
    onClick: () -> Unit
) {
    val timeAgo = remember(status.timestamp) {
        val diff = System.currentTimeMillis() - status.timestamp
        val minutes = (diff / (1000 * 60)).coerceAtLeast(1)
        if (minutes < 60) "${minutes}m ago" else "${minutes / 60}h ago"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .liquidGlass(
                shape = RoundedCornerShape(20.dp),
                backgroundColor = Color(0x2815243C),
                borderBrush = LiquidGlassBorderBrush
            )
            .clickable { onClick() }
            .padding(12.dp)
            .testTag("status_item_${status.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Avatar with iridescent liquid glass ring for unviewed, subtle grey for viewed
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .border(
                    2.2.dp,
                    if (!isViewed) Brush.sweepGradient(
                        listOf(
                            LiquidCyan,
                            LiquidViolet,
                            Color(0xFFFF2A85),
                            LiquidCyan
                        )
                    ) else Brush.linearGradient(listOf(Color(0x44FFFFFF), Color(0x18FFFFFF))),
                    CircleShape
                )
                .padding(3.dp)
        ) {
            AsyncImage(
                model = status.authorAvatarUrl,
                contentDescription = status.authorName,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = status.authorName,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Encrypted Status",
                    tint = LiquidEmerald,
                    modifier = Modifier.size(11.dp)
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = timeAgo,
                color = if (!isViewed) LiquidCyan else Color(0xFF7E8FA7),
                fontSize = 11.5.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = if (!isViewed) FontWeight.SemiBold else FontWeight.Normal
            )
        }

        if (status.mediaUrl != null) {
            LosslessBadge(text = "PHOTO")
        } else {
            LosslessBadge(text = "TEXT")
        }
    }
}
