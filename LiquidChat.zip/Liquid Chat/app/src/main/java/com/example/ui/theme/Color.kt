package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Liquid Glass Palette (iOS 26 Futuristic Aesthetic)
val LiquidDeepObsidian = Color(0xFF080B12)
val LiquidSpaceBlack = Color(0xFF0D121F)
val LiquidMidnightSurface = Color(0xFF141A29)
val LiquidGlassSurface = Color(0x2E253350)
val LiquidGlassSurfaceLight = Color(0x3D354668)
val LiquidGlassBorder = Color(0x38FFFFFF)
val LiquidGlassHighlight = Color(0x80FFFFFF)

// Iridescent Accent Hues
val LiquidCyan = Color(0xFF00F2FE)
val LiquidElectricBlue = Color(0xFF4FACFE)
val LiquidViolet = Color(0xFF8A2BE2)
val LiquidNeonPurple = Color(0xFF9B51E0)
val LiquidMagenta = Color(0xFFFF2A85)
val LiquidEmerald = Color(0xFF00F5A0)
val LiquidAmber = Color(0xFFFFB300)

// Gradients
val LiquidIridescentGradient = Brush.linearGradient(
    colors = listOf(LiquidCyan, LiquidElectricBlue, LiquidNeonPurple)
)

val LiquidBubbleMeGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF007AFF), Color(0xFF6E56FF), Color(0xFFA838FF))
)

val LiquidCallGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF070B18), Color(0xFF131A2F), Color(0xFF201335))
)

val LiquidGlassBorderBrush = Brush.linearGradient(
    colors = listOf(
        Color(0x80FFFFFF),
        Color(0x20FFFFFF),
        Color(0x05FFFFFF),
        Color(0x40FFFFFF)
    )
)
