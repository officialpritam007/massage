package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LiquidDarkColorScheme = darkColorScheme(
    primary = LiquidCyan,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF1E2F48),
    onPrimaryContainer = LiquidCyan,
    secondary = LiquidViolet,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF2C1E4A),
    onSecondaryContainer = Color(0xFFD6C2FF),
    tertiary = LiquidEmerald,
    onTertiary = Color.Black,
    background = LiquidDeepObsidian,
    onBackground = Color(0xFFF0F4FC),
    surface = LiquidMidnightSurface,
    onSurface = Color(0xFFF0F4FC),
    surfaceVariant = LiquidGlassSurface,
    onSurfaceVariant = Color(0xFFBAC7DF),
    outline = LiquidGlassBorder,
    outlineVariant = Color(0x1AFFFFFF)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to deep liquid glass dark mode
    dynamicColor: Boolean = false, // Keep bespoke iOS 26 liquid aesthetic
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = LiquidDarkColorScheme,
        typography = Typography,
        content = content
    )
}
