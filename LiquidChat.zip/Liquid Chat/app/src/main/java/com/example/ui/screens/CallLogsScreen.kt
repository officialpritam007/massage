package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.CallDirection
import com.example.data.model.CallLogEntity
import com.example.data.model.CallType
import com.example.data.model.ContactEntity
import com.example.ui.components.LosslessBadge
import com.example.ui.components.liquidGlass
import com.example.ui.theme.LiquidCyan
import com.example.ui.theme.LiquidEmerald
import com.example.ui.theme.LiquidGlassBorder
import com.example.ui.theme.LiquidGlassBorderBrush
import com.example.ui.theme.LiquidMagenta
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CallLogsScreen(
    callLogs: List<CallLogEntity>,
    contactsMap: Map<String, ContactEntity>,
    onStartCall: (ContactEntity, CallType) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("call_logs_screen")
    ) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .liquidGlass(
                    shape = RoundedCornerShape(22.dp),
                    backgroundColor = Color(0x33121B2F),
                    borderBrush = LiquidGlassBorderBrush
                )
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Global Calls",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Lossless 48kHz Opus • AV1 1080p60 E2EE",
                        color = LiquidCyan,
                        fontSize = 11.sp
                    )
                }

                LosslessBadge(text = "ZERO LATENCY")
            }
        }

        if (callLogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.PhoneInTalk,
                        contentDescription = null,
                        tint = Color(0x66FFFFFF),
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No call logs yet",
                        color = Color(0xFFBACDE8),
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(callLogs, key = { it.id }) { log ->
                    val contact = contactsMap[log.contactId]
                    val contactName = contact?.name ?: "Unknown Contact"
                    val avatarUrl = contact?.avatarUrl ?: ""
                    val isVideo = log.callType == CallType.VIDEO

                    val minutes = log.durationSeconds / 60
                    val seconds = log.durationSeconds % 60
                    val durationStr = if (log.direction == CallDirection.MISSED) "Missed" else String.format("%02d:%02d", minutes, seconds)
                    val timeStr = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(log.timestamp))

                    Row(
                        modifier = Modifier
                            .animateItem()
                            .fillMaxWidth()
                            .liquidGlass(
                                shape = RoundedCornerShape(18.dp),
                                backgroundColor = Color(0x2E16243D),
                                borderBrush = LiquidGlassBorderBrush
                            )
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Contact avatar
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .border(1.dp, LiquidGlassBorderBrush, CircleShape)
                        ) {
                            AsyncImage(
                                model = avatarUrl,
                                contentDescription = contactName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        // Info
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = contactName,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Encrypted",
                                    tint = LiquidEmerald,
                                    modifier = Modifier.size(11.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = when (log.direction) {
                                        CallDirection.INCOMING -> Icons.AutoMirrored.Filled.CallReceived
                                        CallDirection.OUTGOING -> Icons.AutoMirrored.Filled.CallMade
                                        CallDirection.MISSED -> Icons.AutoMirrored.Filled.CallMissed
                                    },
                                    contentDescription = null,
                                    tint = when (log.direction) {
                                        CallDirection.MISSED -> Color(0xFFFF453A)
                                        else -> LiquidEmerald
                                    },
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "$durationStr • $timeStr",
                                    color = Color(0xFFA5B8D4),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        // Call back button
                        IconButton(
                            onClick = {
                                if (contact != null) {
                                    onStartCall(contact, log.callType)
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0x22FFFFFF))
                                .border(1.dp, LiquidGlassBorder, CircleShape)
                        ) {
                            Icon(
                                imageVector = if (isVideo) Icons.Default.Videocam else Icons.Default.Call,
                                contentDescription = "Call back",
                                tint = if (isVideo) LiquidMagenta else LiquidCyan,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
