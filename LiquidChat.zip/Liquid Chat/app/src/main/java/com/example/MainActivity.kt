package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.example.data.db.AppDatabase
import com.example.data.repository.ChatRepository
import com.example.ui.MainViewModel
import com.example.ui.MainViewModelFactory
import com.example.ui.screens.CallScreen
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.UiCustomizerScreen
import com.example.ui.theme.LiquidDeepObsidian
import com.example.ui.theme.MyApplicationTheme

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith

enum class ActiveScreenType {
    HOME,
    CHAT,
    CUSTOMIZER,
    CALL
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        val db = AppDatabase.getDatabase(applicationContext)
        val repo = ChatRepository(db, lifecycleScope)
        MainViewModelFactory(repo)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = LiquidDeepObsidian
                ) {
                    LiquidChatApp(viewModel)
                }
            }
        }
    }
}

@Composable
fun LiquidChatApp(viewModel: MainViewModel) {
    val chats by viewModel.chats.collectAsStateWithLifecycle()
    val groups by viewModel.groups.collectAsStateWithLifecycle()
    val contactsList by viewModel.contacts.collectAsStateWithLifecycle()
    val callLogs by viewModel.callLogs.collectAsStateWithLifecycle()
    val statuses by viewModel.statuses.collectAsStateWithLifecycle()
    val activeChatId by viewModel.activeChatId.collectAsStateWithLifecycle()
    val activeChatMessages by viewModel.activeChatMessages.collectAsStateWithLifecycle()
    val activeCall by viewModel.activeCall.collectAsStateWithLifecycle()
    val typingMap by viewModel.isSimulatedTyping.collectAsStateWithLifecycle()

    val accounts by viewModel.accounts.collectAsStateWithLifecycle()
    val activeAccountId by viewModel.activeAccountId.collectAsStateWithLifecycle()
    val uiConfig by viewModel.uiConfig.collectAsStateWithLifecycle()

    var isUiCustomizerOpen by remember { mutableStateOf(false) }

    val contactsMap = remember(contactsList) {
        contactsList.associateBy { it.id }
    }

    val call = activeCall
    val currentScreenType = when {
        call != null && call.isActive && call.contact != null -> ActiveScreenType.CALL
        isUiCustomizerOpen -> ActiveScreenType.CUSTOMIZER
        activeChatId != null -> ActiveScreenType.CHAT
        else -> ActiveScreenType.HOME
    }

    AnimatedContent(
        targetState = currentScreenType,
        transitionSpec = {
            when {
                targetState == ActiveScreenType.CALL -> {
                    (scaleIn(initialScale = 0.9f, animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) + fadeIn())
                        .togetherWith(fadeOut())
                }
                initialState == ActiveScreenType.CALL -> {
                    fadeIn().togetherWith(scaleOut(targetScale = 0.9f) + fadeOut())
                }
                targetState == ActiveScreenType.CUSTOMIZER -> {
                    (slideInVertically(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn())
                        .togetherWith(slideOutVertically { -it / 3 } + fadeOut())
                }
                initialState == ActiveScreenType.CUSTOMIZER -> {
                    (slideInVertically { -it / 3 } + fadeIn())
                        .togetherWith(slideOutVertically(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) { it } + fadeOut())
                }
                targetState == ActiveScreenType.CHAT -> {
                    (slideInHorizontally(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn())
                        .togetherWith(slideOutHorizontally { -it / 3 } + fadeOut())
                }
                initialState == ActiveScreenType.CHAT -> {
                    (slideInHorizontally { -it / 3 } + fadeIn())
                        .togetherWith(slideOutHorizontally(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) { it } + fadeOut())
                }
                else -> {
                    fadeIn(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
                        .togetherWith(fadeOut())
                }
            }
        },
        label = "main_screen_nav"
    ) { screen ->
        when (screen) {
            ActiveScreenType.CALL -> {
                if (call != null && call.isActive && call.contact != null) {
                    CallScreen(
                        callState = call,
                        onEndCall = { viewModel.endCall() },
                        onToggleMute = { viewModel.toggleMute() },
                        onToggleVideo = { viewModel.toggleVideo() },
                        onFlipCamera = { viewModel.flipCamera() },
                        onToggleSpeaker = { viewModel.toggleSpeaker() }
                    )
                }
            }
            ActiveScreenType.CUSTOMIZER -> {
                UiCustomizerScreen(
                    config = uiConfig,
                    onUpdateConfig = { viewModel.updateUiConfig(it) },
                    onResetConfig = { viewModel.resetUiConfig() },
                    onBack = { isUiCustomizerOpen = false }
                )
            }
            ActiveScreenType.CHAT -> {
                val group = groups.find { it.id == activeChatId }
                val contact = contactsMap[activeChatId]

                if (group != null) {
                    val syntheticContact = com.example.data.model.ContactEntity(
                        id = group.id,
                        name = group.name,
                        avatarUrl = group.avatarUrl,
                        statusText = group.description,
                        location = "${group.category} Channel",
                        relayNode = group.encryptionProtocol,
                        isOnline = true,
                        lastSeen = "Active",
                        publicKeyFingerprint = "MLS • TREEKEM • 256 • RATCHET"
                    )
                    ChatDetailScreen(
                        contact = syntheticContact,
                        group = group,
                        contactsMap = contactsMap,
                        messages = activeChatMessages,
                        isTyping = typingMap[activeChatId] == true,
                        uiConfig = uiConfig,
                        onBack = { viewModel.clearActiveChat() },
                        onSendMessage = { text -> viewModel.sendMessage(text) },
                        onSendMedia = { type, uri, name, size, spec, checksum ->
                            viewModel.sendMedia(type, uri, name, size, spec, checksum)
                        },
                        onSendVoice = { duration, wave -> viewModel.sendVoice(duration, wave) },
                        onStartCall = { targetContact, type -> viewModel.startCall(targetContact, type) },
                        onDeleteGroup = { viewModel.deleteGroup(it) }
                    )
                } else if (contact != null) {
                    ChatDetailScreen(
                        contact = contact,
                        group = null,
                        contactsMap = contactsMap,
                        messages = activeChatMessages,
                        isTyping = typingMap[activeChatId] == true,
                        uiConfig = uiConfig,
                        onBack = { viewModel.clearActiveChat() },
                        onSendMessage = { text -> viewModel.sendMessage(text) },
                        onSendMedia = { type, uri, name, size, spec, checksum ->
                            viewModel.sendMedia(type, uri, name, size, spec, checksum)
                        },
                        onSendVoice = { duration, wave -> viewModel.sendVoice(duration, wave) },
                        onStartCall = { targetContact, type -> viewModel.startCall(targetContact, type) }
                    )
                }
            }
            ActiveScreenType.HOME -> {
                HomeScreen(
                    chats = chats,
                    groups = groups,
                    contactsMap = contactsMap,
                    contactsList = contactsList,
                    callLogs = callLogs,
                    statuses = statuses,
                    accounts = accounts,
                    activeAccountId = activeAccountId,
                    uiConfig = uiConfig,
                    onSelectChat = { chatId -> viewModel.selectChat(chatId) },
                    onStartCall = { targetContact, type -> viewModel.startCall(targetContact, type) },
                    onPostStatus = { caption, mediaUrl, gradientIndex ->
                        viewModel.postStatus(caption, mediaUrl, gradientIndex)
                    },
                    onMarkStatusViewed = { statusId ->
                        viewModel.markStatusViewed(statusId)
                    },
                    onCreateGroup = { name, desc, cat, avatar, members ->
                        viewModel.createGroup(name, desc, cat, avatar, members) { newId ->
                            viewModel.selectChat(newId)
                        }
                    },
                    onDeleteGroup = { groupId ->
                        viewModel.deleteGroup(groupId)
                    },
                    onSwitchAccount = { accountId ->
                        viewModel.switchAccount(accountId)
                    },
                    onUpdateAccount = { updatedAccount ->
                        viewModel.updateAccount(updatedAccount)
                    },
                    onOpenUiCustomizer = {
                        isUiCustomizerOpen = true
                    }
                )
            }
        }
    }
}
