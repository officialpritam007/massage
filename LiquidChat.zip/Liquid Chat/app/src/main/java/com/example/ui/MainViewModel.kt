package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.CallLogEntity
import com.example.data.model.CallType
import com.example.data.model.ChatEntity
import com.example.data.model.ContactEntity
import com.example.data.model.MediaType
import com.example.data.model.MessageEntity
import com.example.data.repository.ActiveCallState
import com.example.data.repository.ChatRepository
import com.example.data.model.AccountProfile
import com.example.data.model.DefaultAccounts
import com.example.data.model.UiCustomizationConfig
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(
    private val repository: ChatRepository
) : ViewModel() {

    val chats: StateFlow<List<ChatEntity>> = repository.allChats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val groups: StateFlow<List<com.example.data.model.GroupEntity>> = repository.allGroups
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val contacts: StateFlow<List<ContactEntity>> = repository.allContacts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val callLogs: StateFlow<List<CallLogEntity>> = repository.allCallLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val statuses: StateFlow<List<com.example.data.model.StatusEntity>> = repository.allStatuses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Multi-Account Profile State (2 Accounts)
    private val _accounts = MutableStateFlow<List<AccountProfile>>(DefaultAccounts)
    val accounts = _accounts.asStateFlow()

    private val _activeAccountId = MutableStateFlow("acc_primary")
    val activeAccountId = _activeAccountId.asStateFlow()

    // UI Customization State
    private val _uiConfig = MutableStateFlow(UiCustomizationConfig())
    val uiConfig = _uiConfig.asStateFlow()

    val activeCall: StateFlow<ActiveCallState?> = repository.activeCall

    val isSimulatedTyping = repository.isSimulatedTyping

    private val _activeChatId = MutableStateFlow<String?>(null)
    val activeChatId = _activeChatId.asStateFlow()

    val activeChatMessages: StateFlow<List<MessageEntity>> = _activeChatId
        .flatMapLatest { chatId ->
            if (chatId != null) {
                repository.getMessagesForChat(chatId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectChat(chatId: String) {
        _activeChatId.value = chatId
        viewModelScope.launch {
            if (chatId.startsWith("grp_")) {
                repository.markGroupAsRead(chatId)
            } else {
                repository.markAsRead(chatId)
            }
        }
    }

    fun createGroup(
        name: String,
        description: String,
        category: String,
        avatarUrl: String,
        memberIds: List<String>,
        onCreated: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val newGroupId = repository.createGroup(name, description, category, avatarUrl, memberIds)
            onCreated(newGroupId)
        }
    }

    fun deleteGroup(groupId: String) {
        viewModelScope.launch {
            repository.deleteGroup(groupId)
            if (_activeChatId.value == groupId) {
                _activeChatId.value = null
            }
        }
    }

    fun clearActiveChat() {
        _activeChatId.value = null
    }

    fun sendMessage(text: String) {
        val chatId = _activeChatId.value ?: return
        viewModelScope.launch {
            repository.sendTextMessage(chatId, text)
        }
    }

    fun sendMedia(
        type: MediaType,
        uri: String,
        name: String,
        sizeBytes: Long,
        spec: String,
        checksum: String
    ) {
        val chatId = _activeChatId.value ?: return
        viewModelScope.launch {
            repository.sendLosslessMedia(
                chatId = chatId,
                mediaType = type,
                mediaUri = uri,
                mediaName = name,
                sizeBytes = sizeBytes,
                resolutionOrSpec = spec,
                checksum = checksum
            )
        }
    }

    fun sendVoice(durationSeconds: Int, waveform: String) {
        val chatId = _activeChatId.value ?: return
        viewModelScope.launch {
            repository.sendVoiceNote(chatId, durationSeconds, waveform)
        }
    }

    fun startCall(contact: ContactEntity, type: CallType) {
        repository.startCall(contact, type)
    }

    fun endCall() {
        repository.endCall()
    }

    fun toggleMute() {
        repository.toggleMute()
    }

    fun toggleVideo() {
        repository.toggleVideo()
    }

    fun flipCamera() {
        repository.flipCamera()
    }

    fun toggleSpeaker() {
        repository.toggleSpeaker()
    }

    fun postStatus(caption: String, mediaUrl: String?, gradientIndex: Int) {
        viewModelScope.launch {
            repository.postStatus(caption, mediaUrl, gradientIndex)
        }
    }

    fun markStatusViewed(statusId: Long) {
        viewModelScope.launch {
            repository.markStatusViewed(statusId)
        }
    }

    fun deleteStatus(statusId: Long) {
        viewModelScope.launch {
            repository.deleteStatus(statusId)
        }
    }

    // Account Switcher Operations
    fun switchAccount(accountId: String) {
        _activeAccountId.value = accountId
    }

    fun updateAccount(updated: AccountProfile) {
        _accounts.value = _accounts.value.map {
            if (it.id == updated.id) updated else it
        }
    }

    // UI Customization Operations
    fun updateUiConfig(newConfig: UiCustomizationConfig) {
        _uiConfig.value = newConfig
    }

    fun resetUiConfig() {
        _uiConfig.value = UiCustomizationConfig()
    }
}

class MainViewModelFactory(
    private val repository: ChatRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
