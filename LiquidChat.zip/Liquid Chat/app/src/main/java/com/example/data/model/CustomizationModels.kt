package com.example.data.model

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

enum class BackdropTheme(val label: String) {
    IRIDESCENT_FLUID("Iridescent Fluid Mesh"),
    DEEP_COSMIC("Deep Cosmic Nebula"),
    EMERALD_MATRIX("Emerald Oceanic Wave"),
    PURE_OBSIDIAN("Pure Obsidian Glass"),
    AURORA_BOREALIS("Aurora Borealis Fluid"),
    MERCURY_CHROME("Liquid Mercury Chrome")
}

enum class BubbleStyle(val label: String) {
    LIQUID_GRADIENT("Liquid Iridescent"),
    NEON_GLASS("Neon Glass Pill"),
    DEEP_SAPPHIRE("Deep Frosted Sapphire"),
    SOLID_COBALT("Solid Cobalt")
}

enum class PartnerBubbleStyle(val label: String) {
    FROSTED_GLASS("Liquid Frosted Glass"),
    TRANSLUCENT_SHEER("Translucent Sheer"),
    SLATE_MINIMAL("Slate Minimal Glass")
}

data class ColorPreset(
    val id: String,
    val name: String,
    val primary: Long,
    val secondary: Long
)

val AvailableColorPresets = listOf(
    ColorPreset("cyan", "Liquid Cyan", 0xFF00F2FE, 0xFF8A2BE2),
    ColorPreset("purple", "Neon Violet", 0xFF9B51E0, 0xFFFF2A85),
    ColorPreset("emerald", "Emerald Glow", 0xFF00F5A0, 0xFF00D2FF),
    ColorPreset("magenta", "Hot Magenta", 0xFFFF2A85, 0xFF7000FF),
    ColorPreset("amber", "Solar Amber", 0xFFFFB300, 0xFFFF416C),
    ColorPreset("diamond", "Diamond Ice", 0xFFE0F7FA, 0xFF0072FF),
    ColorPreset("cobalt", "Cyber Cobalt", 0xFF007AFF, 0xFF6E56FF),
    ColorPreset("rose", "Liquid Rose", 0xFFFF758C, 0xFFFF7EB3),
    ColorPreset("lime", "Neon Lime", 0xFF00FF87, 0xFF60EFFF),
    ColorPreset("indigo", "Electric Indigo", 0xFF6366F1, 0xFFA855F7)
)

data class UiCustomizationConfig(
    val primaryAccentHex: Long = 0xFF00F2FEL,
    val secondaryAccentHex: Long = 0xFF8A2BE2L,
    val glassOpacity: Float = 0.28f, // 0.12f to 0.60f
    val specularBorderAlpha: Float = 0.55f, // 0.15f to 1.0f
    val cornerRadiusDp: Int = 24, // 14, 20, 24, 28
    val backdropTheme: BackdropTheme = BackdropTheme.IRIDESCENT_FLUID,
    val bubbleStyle: BubbleStyle = BubbleStyle.LIQUID_GRADIENT,
    val partnerBubbleStyle: PartnerBubbleStyle = PartnerBubbleStyle.FROSTED_GLASS,
    val chatFontSizeSp: Int = 15, // 13, 15, 17
    val showLosslessBadges: Boolean = true,
    val showTimestamps: Boolean = true,
    val enableDynamicOrbs: Boolean = true
) {
    val primaryAccent: Color get() = Color(primaryAccentHex)
    val secondaryAccent: Color get() = Color(secondaryAccentHex)

    fun getMyBubbleBrush(): Brush {
        return when (bubbleStyle) {
            BubbleStyle.LIQUID_GRADIENT -> Brush.linearGradient(
                listOf(primaryAccent, secondaryAccent)
            )
            BubbleStyle.NEON_GLASS -> Brush.linearGradient(
                listOf(primaryAccent.copy(alpha = 0.45f), secondaryAccent.copy(alpha = 0.35f))
            )
            BubbleStyle.DEEP_SAPPHIRE -> Brush.linearGradient(
                listOf(Color(0xFF0F3057), Color(0xFF00587A))
            )
            BubbleStyle.SOLID_COBALT -> Brush.linearGradient(
                listOf(Color(0xFF007AFF), Color(0xFF0056B3))
            )
        }
    }

    fun getPartnerBubbleBrush(): Brush {
        return when (partnerBubbleStyle) {
            PartnerBubbleStyle.FROSTED_GLASS -> Brush.linearGradient(
                listOf(
                    Color(0x3519263E).copy(alpha = glassOpacity),
                    Color(0x28121B2F).copy(alpha = glassOpacity)
                )
            )
            PartnerBubbleStyle.TRANSLUCENT_SHEER -> Brush.linearGradient(
                listOf(
                    Color(0x18FFFFFF).copy(alpha = (glassOpacity * 0.7f).coerceAtLeast(0.08f)),
                    Color(0x0CFFFFFF).copy(alpha = (glassOpacity * 0.5f).coerceAtLeast(0.04f))
                )
            )
            PartnerBubbleStyle.SLATE_MINIMAL -> Brush.linearGradient(
                listOf(
                    Color(0x50101826).copy(alpha = glassOpacity.coerceAtLeast(0.35f)),
                    Color(0x400C121E).copy(alpha = glassOpacity.coerceAtLeast(0.30f))
                )
            )
        }
    }
}

data class AccountProfile(
    val id: String,
    val displayName: String,
    val handle: String,
    val avatarUrl: String,
    val statusBio: String,
    val phoneNumber: String,
    val relayNode: String,
    val keyFingerprint: String
)

val DefaultAccounts = listOf(
    AccountProfile(
        id = "acc_primary",
        displayName = "Alex Rivers",
        handle = "@alex.rivers",
        avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80",
        statusBio = "Liquid Glass • 48MP Lossless RAW enthusiast 📸",
        phoneNumber = "+1 (555) 019-2831",
        relayNode = "Zurich Hyper-Relay (14ms)",
        keyFingerprint = "7F82 • 43A1 • 9CE0 • 28BB • FA31 • 01DC"
    ),
    AccountProfile(
        id = "acc_secondary",
        displayName = "Alex Vance (Secure / Work)",
        handle = "@vance.work",
        avatarUrl = "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80",
        statusBio = "Quantum Enclave Node • Zero-knowledge E2EE 🔒",
        phoneNumber = "+41 44 215 9000",
        relayNode = "Tokyo Quantum Mesh (9ms)",
        keyFingerprint = "18BC • 92DF • 4488 • C310 • EE90 • 551A"
    )
)
