package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MessageStatus {
    SENDING,
    SENT,
    DELIVERED,
    READ
}

enum class MediaType {
    NONE,
    PHOTO,
    VIDEO,
    DOCUMENT,
    VOICE
}

enum class CallType {
    VOICE,
    VIDEO
}

enum class CallDirection {
    INCOMING,
    OUTGOING,
    MISSED
}

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey val id: String,
    val name: String,
    val avatarUrl: String,
    val statusText: String,
    val location: String, // e.g., "Zurich, Switzerland"
    val relayNode: String, // e.g., "EU-Central (14ms)"
    val isOnline: Boolean,
    val lastSeen: String,
    val publicKeyFingerprint: String // e.g. "8F2A • C491 • 01BB • 99F2"
)

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey val id: String,
    val contactId: String,
    val lastMessage: String,
    val lastMessageTime: Long,
    val unreadCount: Int = 0,
    val isPinned: Boolean = false,
    val isArchived: Boolean = false,
    val isE2EEActive: Boolean = true
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chatId: String,
    val senderId: String, // "me" or contactId
    val content: String,
    val timestamp: Long,
    val status: MessageStatus = MessageStatus.SENT,
    val isEncrypted: Boolean = true,
    val encryptionCipher: String = "AES-256-GCM / Liquid Ratchet v4",
    val mediaType: MediaType = MediaType.NONE,
    val mediaUri: String? = null,
    val mediaName: String? = null,
    val mediaSizeBytes: Long = 0L,
    val mediaResolution: String? = null, // e.g. "48MP (8064x6048) RAW" or "4K ProRes 60fps"
    val mediaChecksum: String? = null,   // e.g. "SHA256: 7f83b1657ff1..."
    val audioDurationSeconds: Int = 0,
    val audioWaveform: String? = null,    // comma-separated heights for visualization
    val isLossless: Boolean = true
)

@Entity(tableName = "call_logs")
data class CallLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contactId: String,
    val callType: CallType,
    val direction: CallDirection,
    val timestamp: Long,
    val durationSeconds: Int,
    val qualityCodec: String = "Opus 48kHz / AV1 Lossless",
    val isEncrypted: Boolean = true
)

@Entity(tableName = "statuses")
data class StatusEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contactId: String, // "me" or contact id
    val authorName: String,
    val authorAvatarUrl: String,
    val mediaUrl: String? = null,
    val textCaption: String = "",
    val backgroundGradientIndex: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val isViewed: Boolean = false,
    val viewsCount: Int = 0,
    val isLossless: Boolean = true
)

@Entity(tableName = "groups")
data class GroupEntity(
    @PrimaryKey val id: String,
    val name: String,
    val avatarUrl: String,
    val description: String,
    val memberIds: String, // comma-separated contact IDs, e.g. "elena,liam,aiko,marcus"
    val lastMessage: String,
    val lastMessageTime: Long,
    val lastSenderName: String = "",
    val unreadCount: Int = 0,
    val isPinned: Boolean = false,
    val category: String = "Engineering",
    val encryptionProtocol: String = "MLS TreeKEM v1 / 256-bit Ratchet",
    val createdAt: Long = System.currentTimeMillis()
)

