package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ContactEntity
import com.example.data.model.GroupEntity
import com.example.data.model.UiCustomizationConfig
import com.example.ui.components.LosslessBadge
import com.example.ui.components.liquidGlass
import com.example.ui.components.liquidPill
import com.example.ui.theme.LiquidCyan
import com.example.ui.theme.LiquidElectricBlue
import com.example.ui.theme.LiquidEmerald
import com.example.ui.theme.LiquidGlassBorder
import com.example.ui.theme.LiquidGlassBorderBrush
import com.example.ui.theme.LiquidMagenta
import com.example.ui.theme.LiquidViolet
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupsScreen(
    groups: List<GroupEntity>,
    contactsMap: Map<String, ContactEntity>,
    contactsList: List<ContactEntity>,
    uiConfig: UiCustomizationConfig,
    onSelectGroup: (String) -> Unit,
    onCreateGroup: (name: String, description: String, category: String, avatarUrl: String, memberIds: List<String>) -> Unit,
    onDeleteGroup: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf("All") }
    var showCreateGroupSheet by remember { mutableStateOf(false) }
    var inspectedGroup by remember { mutableStateOf<GroupEntity?>(null) }

    val categories = listOf("All", "Engineering", "Security", "Studio", "Network", "Unread")

    val filteredGroups = groups.filter { group ->
        val matchesQuery = searchQuery.isBlank() ||
                group.name.contains(searchQuery, ignoreCase = true) ||
                group.description.contains(searchQuery, ignoreCase = true) ||
                group.lastMessage.contains(searchQuery, ignoreCase = true)

        val matchesCategory = when (selectedCategory) {
            "All" -> true
            "Unread" -> group.unreadCount > 0
            else -> group.category.equals(selectedCategory, ignoreCase = true)
        }

        matchesQuery && matchesCategory
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("groups_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Liquid Glass Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .liquidGlass(
                        shape = RoundedCornerShape(26.dp),
                        backgroundColor = Color(0x2E121B2F),
                        borderWidth = 0.8.dp,
                        borderBrush = LiquidGlassBorderBrush
                    )
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Encrypted Groups",
                                    color = Color.White,
                                    fontSize = 19.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.3.sp
                                )
                                LosslessBadge(text = "MLS TreeKEM")
                            }
                            Text(
                                text = "Zero-Knowledge Multi-Party Ratchets",
                                color = uiConfig.primaryAccent,
                                fontSize = 10.5.sp
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            // Search toggle button
                            IconButton(
                                onClick = { isSearchActive = !isSearchActive },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0x1AFFFFFF))
                                    .testTag("groups_search_toggle")
                            ) {
                                Icon(
                                    imageVector = if (isSearchActive) Icons.Default.Close else Icons.Default.Search,
                                    contentDescription = "Search Groups",
                                    tint = if (isSearchActive) uiConfig.primaryAccent else Color.White,
                                    modifier = Modifier.size(17.dp)
                                )
                            }

                            // Create Group FAB-like Header Button
                            IconButton(
                                onClick = { showCreateGroupSheet = true },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(uiConfig.primaryAccent)
                                    .testTag("create_group_header_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "New Group",
                                    tint = Color.Black,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    // Search input expansion
                    AnimatedVisibility(
                        visible = isSearchActive,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp)
                                .liquidPill(backgroundColor = Color(0x33101828))
                                .padding(horizontal = 12.dp, vertical = 2.dp)
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = {
                                    Text(
                                        text = "Search encrypted channels & topics...",
                                        color = Color(0xFF7A8C9E),
                                        fontSize = 12.5.sp
                                    )
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    cursorColor = uiConfig.primaryAccent
                                ),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                    }
                }
            }

            // Quick Stats Ribbon
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatPill(
                    icon = Icons.Default.Groups,
                    label = "${groups.size} Channels",
                    accent = uiConfig.primaryAccent,
                    modifier = Modifier.weight(1f)
                )
                StatPill(
                    icon = Icons.Default.Security,
                    label = "256-bit Ratchet",
                    accent = LiquidEmerald,
                    modifier = Modifier.weight(1f)
                )
                StatPill(
                    icon = Icons.Default.Public,
                    label = "Mesh Synced",
                    accent = LiquidViolet,
                    modifier = Modifier.weight(1f)
                )
            }

            // Category Filter Pills
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentPadding = PaddingValues(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { category ->
                    val isSelected = selectedCategory == category
                    val chipScale by animateFloatAsState(
                        targetValue = if (isSelected) 1.05f else 1.0f,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
                        label = "grp_chip_$category"
                    )
                    Box(
                        modifier = Modifier
                            .graphicsLayer {
                                scaleX = chipScale
                                scaleY = chipScale
                            }
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (isSelected) Brush.linearGradient(
                                    listOf(uiConfig.primaryAccent, uiConfig.secondaryAccent)
                                ) else SolidColor(Color(0x22162540))
                            )
                            .border(
                                0.8.dp,
                                if (isSelected) uiConfig.primaryAccent else Color(0x1AFFFFFF),
                                RoundedCornerShape(14.dp)
                            )
                            .clickable { selectedCategory = category }
                            .padding(horizontal = 12.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = category,
                            color = if (isSelected) Color.Black else Color(0xFFBACADC),
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            // Group Cards List
            if (filteredGroups.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color(0x1A00E5FF))
                                .border(1.dp, Color(0x4400E5FF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Groups,
                                contentDescription = null,
                                tint = uiConfig.primaryAccent,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Text(
                            text = "No encrypted groups found",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Tap '+ New Group' above to launch an E2EE channel with team members",
                            color = Color(0xFF7E8EA4),
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredGroups, key = { it.id }) { group ->
                        val memberIdList = remember(group.memberIds) {
                            group.memberIds.split(",").filter { it.isNotBlank() }
                        }
                        val memberContacts = remember(memberIdList, contactsMap) {
                            memberIdList.mapNotNull { contactsMap[it] }
                        }
                        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault())
                            .format(Date(group.lastMessageTime))

                        GroupCard(
                            group = group,
                            memberContacts = memberContacts,
                            timeStr = timeStr,
                            uiConfig = uiConfig,
                            modifier = Modifier.animateItem(),
                            onClick = { onSelectGroup(group.id) },
                            onInspect = { inspectedGroup = group }
                        )
                    }
                }
            }
        }

        // Floating Action Button to Create Group
        FloatingActionButton(
            onClick = { showCreateGroupSheet = true },
            containerColor = uiConfig.primaryAccent,
            contentColor = Color.Black,
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 16.dp)
                .size(54.dp)
                .border(1.dp, LiquidGlassBorderBrush, RoundedCornerShape(22.dp))
                .testTag("fab_create_group")
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Create Group",
                modifier = Modifier.size(24.dp)
            )
        }
    }

    // Modal Sheet: Create Group
    if (showCreateGroupSheet) {
        CreateGroupSheet(
            contactsList = contactsList,
            uiConfig = uiConfig,
            onDismiss = { showCreateGroupSheet = false },
            onCreate = { name, desc, cat, avatar, members ->
                onCreateGroup(name, desc, cat, avatar, members)
                showCreateGroupSheet = false
            }
        )
    }

    // Modal Sheet: Group Info & Details
    inspectedGroup?.let { group ->
        val memberIdList = remember(group.memberIds) {
            group.memberIds.split(",").filter { it.isNotBlank() }
        }
        val memberContacts = remember(memberIdList, contactsMap) {
            memberIdList.mapNotNull { contactsMap[it] }
        }

        GroupInfoSheet(
            group = group,
            memberContacts = memberContacts,
            uiConfig = uiConfig,
            onDismiss = { inspectedGroup = null },
            onOpenChat = {
                inspectedGroup = null
                onSelectGroup(group.id)
            },
            onDeleteGroup = {
                onDeleteGroup(group.id)
                inspectedGroup = null
            }
        )
    }
}

@Composable
fun StatPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .liquidGlass(
                shape = RoundedCornerShape(14.dp),
                backgroundColor = Color(0x22131D32),
                borderWidth = 0.6.dp,
                borderBrush = SolidColor(Color(0x22FFFFFF))
            )
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(13.dp)
            )
            Text(
                text = label,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun GroupCard(
    group: GroupEntity,
    memberContacts: List<ContactEntity>,
    timeStr: String,
    uiConfig: UiCustomizationConfig,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onInspect: () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .liquidGlass(
                shape = RoundedCornerShape(22.dp),
                backgroundColor = Color(0x2814233C),
                borderWidth = 0.8.dp,
                borderBrush = if (group.unreadCount > 0) SolidColor(uiConfig.primaryAccent.copy(alpha = 0.6f)) else LiquidGlassBorderBrush
            )
            .clickable { onClick() }
            .padding(12.dp)
            .testTag("group_card_${group.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Group Avatar with category badge
            Box(modifier = Modifier.size(52.dp)) {
                AsyncImage(
                    model = group.avatarUrl,
                    contentDescription = group.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.2.dp, LiquidGlassBorderBrush, RoundedCornerShape(16.dp))
                )

                // Category mini icon badge
                val categoryIcon = when (group.category.lowercase()) {
                    "engineering" -> Icons.Default.Code
                    "security" -> Icons.Default.Shield
                    "studio" -> Icons.Default.MusicNote
                    else -> Icons.Default.Groups
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(uiConfig.primaryAccent)
                        .border(1.5.dp, Color(0xFF080B14), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = categoryIcon,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(9.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Info column
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        Text(
                            text = group.name,
                            color = Color.White,
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "E2EE",
                            tint = uiConfig.primaryAccent,
                            modifier = Modifier.size(11.dp)
                        )
                        if (group.isPinned) {
                            Icon(
                                imageVector = Icons.Default.PushPin,
                                contentDescription = "Pinned",
                                tint = LiquidCyan,
                                modifier = Modifier.size(10.dp)
                            )
                        }
                    }

                    Text(
                        text = timeStr,
                        color = if (group.unreadCount > 0) uiConfig.primaryAccent else Color(0xFF7E8EA4),
                        fontSize = 10.5.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (group.unreadCount > 0) FontWeight.Bold else FontWeight.Normal
                    )
                }

                Spacer(modifier = Modifier.height(3.dp))

                // Overlapping member avatars preview
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy((-6).dp)) {
                        memberContacts.take(3).forEach { member ->
                            AsyncImage(
                                model = member.avatarUrl,
                                contentDescription = member.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(18.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, Color(0xFF0C1322), CircleShape)
                            )
                        }
                    }

                    Text(
                        text = "${memberContacts.size + 1} members • ${group.category}",
                        color = Color(0xFF8BA0B8),
                        fontSize = 10.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(3.dp))

                // Last Message
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = group.lastMessage,
                        color = if (group.unreadCount > 0) Color.White else Color(0xFF9FB2CA),
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    if (group.unreadCount > 0) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(uiConfig.primaryAccent)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${group.unreadCount}",
                                color = Color.Black,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Inspect info icon button
            IconButton(
                onClick = onInspect,
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(0x14FFFFFF))
                    .testTag("inspect_group_${group.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Group Details",
                    tint = Color(0xFFA1B4CC),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateGroupSheet(
    contactsList: List<ContactEntity>,
    uiConfig: UiCustomizationConfig,
    onDismiss: () -> Unit,
    onCreate: (name: String, description: String, category: String, avatarUrl: String, members: List<String>) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var groupName by remember { mutableStateOf("") }
    var groupTopic by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Engineering") }
    val selectedMembers = remember { mutableStateListOf<String>() }

    val presetAvatars = listOf(
        "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=400&q=80",
        "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=400&q=80",
        "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=400&q=80",
        "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=400&q=80",
        "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=400&q=80"
    )
    var selectedAvatarUrl by remember { mutableStateOf(presetAvatars.first()) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF0F172A),
        contentColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .testTag("create_group_sheet")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "New Encrypted Channel",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Avatar preset selector
            Text(
                text = "Choose Visual Identity",
                color = Color(0xFF9FB2CA),
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                presetAvatars.forEach { url ->
                    val isSelected = selectedAvatarUrl == url
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .border(
                                2.dp,
                                if (isSelected) uiConfig.primaryAccent else Color(0x22FFFFFF),
                                RoundedCornerShape(14.dp)
                            )
                            .clickable { selectedAvatarUrl = url }
                    ) {
                        AsyncImage(
                            model = url,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        if (isSelected) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color(0x44000000)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = uiConfig.primaryAccent,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Name field
            OutlinedTextField(
                value = groupName,
                onValueChange = { groupName = it },
                label = { Text("Channel / Group Name", color = Color(0xFF9FB2CA)) },
                placeholder = { Text("e.g. Liquid Mesh Research", color = Color(0xFF6E7E95)) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("group_name_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = uiConfig.primaryAccent,
                    unfocusedBorderColor = Color(0x33FFFFFF),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Description field
            OutlinedTextField(
                value = groupTopic,
                onValueChange = { groupTopic = it },
                label = { Text("Description & Mission Topic", color = Color(0xFF9FB2CA)) },
                placeholder = { Text("Zero-knowledge mesh channel for developers", color = Color(0xFF6E7E95)) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("group_desc_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = uiConfig.primaryAccent,
                    unfocusedBorderColor = Color(0x33FFFFFF),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Category picker
            Text(
                text = "Select Category",
                color = Color(0xFF9FB2CA),
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Engineering", "Security", "Studio", "Network", "General")) { cat ->
                    val isSel = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSel) uiConfig.primaryAccent else Color(0x1AFFFFFF))
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = cat,
                            color = if (isSel) Color.Black else Color.White,
                            fontSize = 11.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Member selection
            Text(
                text = "Add Mesh Members (${selectedMembers.size} selected)",
                color = Color(0xFF9FB2CA),
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0x1814233C))
                    .border(0.8.dp, Color(0x1AFFFFFF), RoundedCornerShape(14.dp))
                    .padding(6.dp)
            ) {
                items(contactsList, key = { it.id }) { contact ->
                    val isChecked = selectedMembers.contains(contact.id)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                if (isChecked) selectedMembers.remove(contact.id)
                                else selectedMembers.add(contact.id)
                            }
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = contact.avatarUrl,
                            contentDescription = contact.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = contact.name,
                                color = Color.White,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = contact.location,
                                color = Color(0xFF7E8EA4),
                                fontSize = 10.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(if (isChecked) uiConfig.primaryAccent else Color(0x22FFFFFF))
                                .border(1.dp, if (isChecked) uiConfig.primaryAccent else Color(0x44FFFFFF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isChecked) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    if (groupName.isNotBlank()) {
                        onCreate(
                            groupName,
                            groupTopic,
                            selectedCategory,
                            selectedAvatarUrl,
                            selectedMembers.toList()
                        )
                    }
                },
                enabled = groupName.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = uiConfig.primaryAccent,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("submit_create_group_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Initialize Ratchet & Launch Channel",
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupInfoSheet(
    group: GroupEntity,
    memberContacts: List<ContactEntity>,
    uiConfig: UiCustomizationConfig,
    onDismiss: () -> Unit,
    onOpenChat: () -> Unit,
    onDeleteGroup: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF0F172A),
        contentColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .testTag("group_info_sheet")
        ) {
            // Header with Large Avatar & Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(
                    model = group.avatarUrl,
                    contentDescription = group.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .border(1.5.dp, uiConfig.primaryAccent, RoundedCornerShape(18.dp))
                )

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = group.name,
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${memberContacts.size + 1} Encrypted Peers • ${group.category}",
                        color = uiConfig.primaryAccent,
                        fontSize = 11.5.sp
                    )
                    Text(
                        text = group.encryptionProtocol,
                        color = Color(0xFF7E8EA4),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Topic description box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlass(
                        shape = RoundedCornerShape(16.dp),
                        backgroundColor = Color(0x22131D32),
                        borderBrush = LiquidGlassBorderBrush
                    )
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "Topic & Protocol Spec",
                        color = uiConfig.primaryAccent,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = group.description,
                        color = Color.White,
                        fontSize = 12.5.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Member list
            Text(
                text = "Channel Members (${memberContacts.size + 1})",
                color = Color.White,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0x1814233C))
                    .padding(6.dp)
            ) {
                // Self item
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(uiConfig.primaryAccent),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "You", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(text = "You (Primary Node)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.weight(1f))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0x3300E5FF))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = "Creator", color = uiConfig.primaryAccent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                items(memberContacts) { contact ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = contact.avatarUrl,
                            contentDescription = contact.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = contact.name, color = Color.White, fontSize = 12.sp)
                            Text(text = contact.location, color = Color(0xFF7E8EA4), fontSize = 9.5.sp)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0x1AFFFFFF))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = "Member", color = Color(0xFF9FB2CA), fontSize = 9.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onOpenChat,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = uiConfig.primaryAccent,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Open Chat", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onDeleteGroup,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0x33FF3B30),
                        contentColor = Color(0xFFFF5252)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Leave Group", fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
