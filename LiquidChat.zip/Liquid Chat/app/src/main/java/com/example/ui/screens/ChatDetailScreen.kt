package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.CallType
import com.example.data.model.ContactEntity
import com.example.data.model.MediaType
import com.example.data.model.MessageEntity
import com.example.data.model.MessageStatus
import com.example.ui.components.EncryptionFingerprintSheet
import com.example.ui.components.FullscreenLosslessViewerDialog
import com.example.ui.components.LiquidAmbientBackdrop
import com.example.ui.components.LosslessDocumentCard
import com.example.ui.components.LosslessPhotoCard
import com.example.ui.components.LosslessVideoCard
import com.example.ui.components.LosslessVoicePlayer
import com.example.ui.components.liquidGlass
import com.example.ui.theme.LiquidBubbleMeGradient
import com.example.ui.theme.LiquidCyan
import com.example.ui.theme.LiquidElectricBlue
import com.example.ui.theme.LiquidEmerald
import com.example.ui.theme.LiquidGlassBorder
import com.example.ui.theme.LiquidGlassBorderBrush
import com.example.ui.theme.LiquidMagenta
import com.example.ui.theme.LiquidViolet
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    contact: ContactEntity,
    group: com.example.data.model.GroupEntity? = null,
    contactsMap: Map<String, ContactEntity> = emptyMap(),
    messages: List<MessageEntity>,
    isTyping: Boolean,
    uiConfig: com.example.data.model.UiCustomizationConfig = com.example.data.model.UiCustomizationConfig(),
    onBack: () -> Unit,
    onSendMessage: (String) -> Unit,
    onSendMedia: (MediaType, String, String, Long, String, String) -> Unit,
    onSendVoice: (Int, String) -> Unit,
    onStartCall: (ContactEntity, CallType) -> Unit,
    onDeleteGroup: (String) -> Unit = {}
) {
    BackHandler {
        onBack()
    }

    var inputText by remember { mutableStateOf("") }
    var showAttachmentMenu by remember { mutableStateOf(false) }
    var showSecuritySheet by remember { mutableStateOf(false) }
    var fullscreenMedia by remember { mutableStateOf<MessageEntity?>(null) }
    var isRecordingSimulated by remember { mutableStateOf(false) }
    var activeReactionMessageId by remember { mutableStateOf<Long?>(null) }
    var messageReactions by remember { mutableStateOf(mapOf<Long, String>()) }

    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Android Zero-Permission Photo/Video Pickers
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onSendMedia(
                MediaType.PHOTO,
                uri.toString(),
                "PHOTO_${System.currentTimeMillis()}.PNG",
                32_400_000L,
                "48MP Lossless RAW (Zero Compression)",
                "SHA-256: 4f1a28...verified"
            )
            showAttachmentMenu = false
        }
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            onSendMedia(
                MediaType.DOCUMENT,
                uri.toString(),
                "DOCUMENT_${System.currentTimeMillis()}.PDF",
                12_500_000L,
                "Lossless Document Bitstream",
                "SHA-256: d820a4...verified"
            )
            showAttachmentMenu = false
        }
    }

    LiquidAmbientBackdrop(config = uiConfig) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .testTag("chat_detail_screen")
        ) {
            // Liquid Glass Top Navigation Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .liquidGlass(
                        shape = RoundedCornerShape(26.dp),
                        backgroundColor = Color(0x38121B2F),
                        borderBrush = LiquidGlassBorderBrush
                    )
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.size(38.dp).testTag("chat_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Contact Avatar with liquid border
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .border(1.2.dp, LiquidGlassBorderBrush, CircleShape)
                            .clickable { showSecuritySheet = true }
                    ) {
                        AsyncImage(
                            model = contact.avatarUrl,
                            contentDescription = contact.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    // Contact details and presence
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { showSecuritySheet = true }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = contact.name,
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "E2EE",
                                tint = LiquidCyan,
                                modifier = Modifier.size(13.dp)
                            )
                        }

                        val subtitleText = when {
                            isTyping -> if (group != null) "member is typing in real-time..." else "typing in real-time..."
                            group != null -> "${group.category} • ${group.memberIds.split(",").filter { it.isNotBlank() }.size + 1} members"
                            else -> "${contact.location} • ${contact.relayNode}"
                        }
                        Text(
                            text = subtitleText,
                            color = if (isTyping) LiquidCyan else Color(0xFFA5B8D4),
                            fontSize = 10.5.sp,
                            maxLines = 1
                        )
                    }

                    // Voice Call Button
                    IconButton(
                        onClick = { onStartCall(contact, CallType.VOICE) },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0x22FFFFFF))
                            .border(1.dp, LiquidGlassBorder, CircleShape)
                            .testTag("chat_voice_call_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "Voice Call",
                            tint = LiquidCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Video Call Button
                    IconButton(
                        onClick = { onStartCall(contact, CallType.VIDEO) },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0x22FFFFFF))
                            .border(1.dp, LiquidGlassBorder, CircleShape)
                            .testTag("chat_video_call_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = "Video Call",
                            tint = LiquidMagenta,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // E2EE Notice Pill
            Row(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x240A1222))
                    .border(0.8.dp, Color(0x22FFFFFF), RoundedCornerShape(12.dp))
                    .clickable { showSecuritySheet = true }
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = LiquidEmerald,
                    modifier = Modifier.size(11.dp)
                )
                Text(
                    text = "End-to-End Encrypted • Verified Ratchet v4",
                    color = Color(0xFFBACDE8),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Messages Stream
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                contentPadding = PaddingValues(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    val isMe = msg.senderId == "me"
                    val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(msg.timestamp))
                    val reaction = messageReactions[msg.id]

                    Column(
                        modifier = Modifier
                            .animateItem()
                            .fillMaxWidth(),
                        horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
                    ) {
                        // Quick Reaction Palette popup
                        AnimatedVisibility(
                            visible = activeReactionMessageId == msg.id,
                            enter = scaleIn(spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioLowBouncy)) + fadeIn(),
                            exit = scaleOut() + fadeOut()
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(bottom = 6.dp)
                                    .liquidGlass(
                                        shape = RoundedCornerShape(20.dp),
                                        backgroundColor = Color(0xD90E1726),
                                        borderBrush = LiquidGlassBorderBrush
                                    )
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("❤️", "👍", "🔥", "😮", "🚀", "⚡").forEach { emoji ->
                                    Text(
                                        text = emoji,
                                        fontSize = 18.sp,
                                        modifier = Modifier
                                            .clickable {
                                                messageReactions = messageReactions + (msg.id to emoji)
                                                activeReactionMessageId = null
                                            }
                                            .padding(horizontal = 2.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
                        ) {
                            val bubbleShape = RoundedCornerShape(
                                topStart = uiConfig.cornerRadiusDp.dp,
                                topEnd = uiConfig.cornerRadiusDp.dp,
                                bottomStart = if (isMe) uiConfig.cornerRadiusDp.dp else 4.dp,
                                bottomEnd = if (isMe) 4.dp else uiConfig.cornerRadiusDp.dp
                            )

                            Box(
                                modifier = Modifier
                                    .widthIn(max = 310.dp)
                                    .clip(bubbleShape)
                                    .background(
                                        if (isMe) uiConfig.getMyBubbleBrush()
                                        else uiConfig.getPartnerBubbleBrush()
                                    )
                                    .border(
                                        1.dp,
                                        if (isMe) Brush.linearGradient(
                                            listOf(
                                                Color.White.copy(alpha = uiConfig.specularBorderAlpha),
                                                Color.Transparent
                                            )
                                        ) else Brush.linearGradient(
                                            listOf(
                                                Color.White.copy(alpha = uiConfig.specularBorderAlpha * 0.7f),
                                                Color(0x10FFFFFF)
                                            )
                                        ),
                                        bubbleShape
                                    )
                                    .clickable {
                                        activeReactionMessageId = if (activeReactionMessageId == msg.id) null else msg.id
                                    }
                                    .padding(10.dp)
                            ) {
                                Column {
                                    if (group != null && !isMe) {
                                        val sender = contactsMap[msg.senderId]
                                        val senderName = sender?.name ?: msg.senderId
                                        Text(
                                            text = senderName,
                                            color = uiConfig.primaryAccent,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(bottom = 3.dp)
                                        )
                                    }
                                    when (msg.mediaType) {
                                        MediaType.PHOTO -> {
                                            LosslessPhotoCard(
                                                message = msg,
                                                onOpenViewer = { fullscreenMedia = msg }
                                            )
                                        }
                                        MediaType.VIDEO -> {
                                            LosslessVideoCard(
                                                message = msg,
                                                onOpenViewer = { fullscreenMedia = msg }
                                            )
                                        }
                                        MediaType.DOCUMENT -> {
                                            LosslessDocumentCard(message = msg)
                                        }
                                        MediaType.VOICE -> {
                                            LosslessVoicePlayer(message = msg)
                                        }
                                        MediaType.NONE -> {
                                            Text(
                                                text = msg.content,
                                                color = Color.White,
                                                fontSize = uiConfig.chatFontSizeSp.sp,
                                                lineHeight = (uiConfig.chatFontSizeSp + 5).sp
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Row(
                                        modifier = Modifier.align(Alignment.End),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        if (msg.isLossless && uiConfig.showLosslessBadges) {
                                            Text(
                                                text = "LOSSLESS",
                                                color = if (isMe) Color.White else uiConfig.primaryAccent,
                                                fontSize = 8.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        if (uiConfig.showTimestamps) {
                                            Text(
                                                text = timeStr,
                                                color = if (isMe) Color(0xCCFFFFFF) else Color(0xFFA6B7CE),
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }

                                        if (isMe) {
                                            when (msg.status) {
                                                MessageStatus.SENDING -> {
                                                    Icon(
                                                        imageVector = Icons.Default.Check,
                                                        contentDescription = "Sending",
                                                        tint = Color.Gray,
                                                        modifier = Modifier.size(12.dp)
                                                    )
                                                }
                                                MessageStatus.SENT -> {
                                                    Icon(
                                                        imageVector = Icons.Default.Check,
                                                        contentDescription = "Sent",
                                                        tint = Color(0xFFBACADC),
                                                        modifier = Modifier.size(12.dp)
                                                    )
                                                }
                                                MessageStatus.DELIVERED -> {
                                                    Icon(
                                                        imageVector = Icons.Default.DoneAll,
                                                        contentDescription = "Delivered",
                                                        tint = Color(0xFFBACADC),
                                                        modifier = Modifier.size(13.dp)
                                                    )
                                                }
                                                MessageStatus.READ -> {
                                                    Icon(
                                                        imageVector = Icons.Default.DoneAll,
                                                        contentDescription = "Read",
                                                        tint = uiConfig.primaryAccent,
                                                        modifier = Modifier.size(13.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Display active reaction badge
                        reaction?.let { emoji ->
                            Box(
                                modifier = Modifier
                                    .padding(top = 2.dp, start = if (isMe) 0.dp else 8.dp, end = if (isMe) 8.dp else 0.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0x66101B2E))
                                    .border(0.8.dp, Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(text = emoji, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Real-Time Typing Bubble with Bouncing Liquid Dots
            AnimatedVisibility(
                visible = isTyping,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Row(
                    modifier = Modifier
                        .padding(start = 16.dp, bottom = 8.dp)
                        .liquidGlass(
                            shape = RoundedCornerShape(16.dp),
                            backgroundColor = Color(0x3519263E),
                            borderBrush = LiquidGlassBorderBrush
                        )
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LiquidBouncingDots(color = LiquidCyan)
                    Text(
                        text = if (group != null) "Incoming lossless stream from group..." else "${contact.name} is preparing lossless payload...",
                        color = LiquidCyan,
                        fontSize = 11.sp,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                }
            }

            // Attachment Selection Glass Palette
            AnimatedVisibility(
                visible = showAttachmentMenu,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                        .liquidGlass(
                            shape = RoundedCornerShape(22.dp),
                            backgroundColor = Color(0x4D121B2F),
                            borderBrush = LiquidGlassBorderBrush
                        )
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        // Lossless Photo
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clickable {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                                .testTag("attach_photo_button")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(LiquidCyan, LiquidElectricBlue))),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Image, contentDescription = null, tint = Color.Black)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Lossless RAW", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                        }

                        // Lossless 4K Video
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clickable {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                    )
                                }
                                .testTag("attach_video_button")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(LiquidMagenta, LiquidViolet))),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Videocam, contentDescription = null, tint = Color.White)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("4K ProRes", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                        }

                        // Lossless Document
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clickable {
                                    documentPickerLauncher.launch(arrayOf("*/*"))
                                }
                                .testTag("attach_document_button")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(Color(0xFF22C55E), Color(0xFF10B981)))),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Description, contentDescription = null, tint = Color.Black)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Raw File", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                        }

                        // Opus 48kHz Voice Note
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clickable {
                                    onSendVoice(
                                        15,
                                        "30,60,85,90,100,75,40,60,80,95,70,50,65,40"
                                    )
                                    showAttachmentMenu = false
                                }
                                .testTag("attach_voice_button")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(Color(0xFFFF9500), Color(0xFFFF5E3A)))),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Mic, contentDescription = null, tint = Color.White)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Opus 48kHz", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }

            // Bottom Liquid Glass Message Input Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .liquidGlass(
                        shape = RoundedCornerShape(28.dp),
                        backgroundColor = Color(0x3D131C31),
                        borderBrush = LiquidGlassBorderBrush
                    )
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Attachment toggle
                    IconButton(
                        onClick = { showAttachmentMenu = !showAttachmentMenu },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0x22FFFFFF))
                            .border(1.dp, LiquidGlassBorder, CircleShape)
                            .testTag("attachment_menu_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Attachment Options",
                            tint = if (showAttachmentMenu) LiquidCyan else Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Input field
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = {
                            Text(
                                text = "Encrypted message (Lossless)...",
                                color = Color(0xFF8B9FB8),
                                fontSize = 13.5.sp
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = LiquidCyan
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_message_input"),
                        maxLines = 4
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    // Send / Mic Action Button
                    val canSend = inputText.isNotBlank()
                    val sendScale by animateFloatAsState(
                        targetValue = if (canSend) 1.12f else 1.0f,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
                        label = "chat_send_scale"
                    )

                    IconButton(
                        onClick = {
                            if (canSend) {
                                onSendMessage(inputText.trim())
                                inputText = ""
                            } else {
                                // Send simulated lossless audio clip
                                onSendVoice(
                                    10,
                                    "25,40,75,90,80,60,45,70,85,60,40,20"
                                )
                            }
                        },
                        modifier = Modifier
                            .graphicsLayer {
                                scaleX = sendScale
                                scaleY = sendScale
                            }
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(
                                if (canSend) Brush.linearGradient(listOf(uiConfig.primaryAccent, uiConfig.secondaryAccent))
                                else SolidColor(Color(0x2EFFFFFF))
                            )
                            .border(1.dp, LiquidGlassBorderBrush, CircleShape)
                            .testTag("chat_send_button")
                    ) {
                        Icon(
                            imageVector = if (canSend) Icons.AutoMirrored.Filled.Send else Icons.Default.Mic,
                            contentDescription = if (canSend) "Send" else "Record Voice",
                            tint = if (canSend) Color.Black else uiConfig.primaryAccent,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                }
            }
        }

        // Fullscreen Lossless Viewer Modal
        fullscreenMedia?.let { media ->
            FullscreenLosslessViewerDialog(
                message = media,
                onDismiss = { fullscreenMedia = null }
            )
        }

        // Cryptographic Safety Fingerprint Sheet or Group Info
        if (showSecuritySheet) {
            if (group != null) {
                val memberIdList = remember(group.memberIds) {
                    group.memberIds.split(",").filter { it.isNotBlank() }
                }
                val memberContacts = remember(memberIdList, contactsMap) {
                    memberIdList.mapNotNull { contactsMap[it] }
                }
                GroupInfoSheet(
                    group = group,
                    memberContacts = memberContacts,
                    uiConfig = uiConfig,
                    onDismiss = { showSecuritySheet = false },
                    onOpenChat = { showSecuritySheet = false },
                    onDeleteGroup = {
                        onDeleteGroup(group.id)
                        showSecuritySheet = false
                        onBack()
                    }
                )
            } else {
                EncryptionFingerprintSheet(
                    contact = contact,
                    onDismiss = { showSecuritySheet = false }
                )
            }
        }
    }
}

@Composable
fun LiquidBouncingDots(
    color: Color = LiquidCyan,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "bouncing_dots")
    val dot1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -5f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "d1"
    )
    val dot2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -5f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, delayMillis = 130, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "d2"
    )
    val dot3 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -5f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, delayMillis = 260, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "d3"
    )

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .graphicsLayer { translationY = dot1 }
                .size(5.dp)
                .clip(CircleShape)
                .background(color)
        )
        Box(
            modifier = Modifier
                .graphicsLayer { translationY = dot2 }
                .size(5.dp)
                .clip(CircleShape)
                .background(color)
        )
        Box(
            modifier = Modifier
                .graphicsLayer { translationY = dot3 }
                .size(5.dp)
                .clip(CircleShape)
                .background(color)
        )
    }
}
