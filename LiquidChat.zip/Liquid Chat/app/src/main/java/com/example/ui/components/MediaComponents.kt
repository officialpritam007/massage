package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.MessageEntity
import com.example.ui.theme.LiquidCyan
import com.example.ui.theme.LiquidEmerald
import com.example.ui.theme.LiquidGlassBorder
import com.example.ui.theme.LiquidGlassBorderBrush
import com.example.ui.theme.LiquidGlassHighlight
import com.example.ui.theme.LiquidMagenta
import com.example.ui.theme.LiquidViolet
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun LosslessBadge(
    text: String = "LOSSLESS RAW",
    icon: @Composable () -> Unit = {
        Icon(
            imageVector = Icons.Default.Diamond,
            contentDescription = null,
            modifier = Modifier.size(11.dp),
            tint = LiquidCyan
        )
    }
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0x3300F2FE))
            .border(0.8.dp, Brush.linearGradient(listOf(LiquidCyan.copy(alpha = 0.6f), Color(0x1000F2FE))), RoundedCornerShape(10.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        icon()
        Text(
            text = text,
            color = Color.White,
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.6.sp
        )
    }
}

@Composable
fun LosslessPhotoCard(
    message: MessageEntity,
    onOpenViewer: () -> Unit
) {
    val sizeMb = String.format(Locale.US, "%.1f MB", message.mediaSizeBytes / (1024f * 1024f))
    
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .liquidGlass(
                shape = RoundedCornerShape(18.dp),
                backgroundColor = Color(0x3819263E),
                borderBrush = LiquidGlassBorderBrush
            )
            .clickable { onOpenViewer() }
            .padding(6.dp)
            .testTag("lossless_photo_card_${message.id}")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(14.dp))
        ) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(message.mediaUri)
                    .crossfade(true)
                    .build(),
                contentDescription = "Lossless Photo",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Top overlay badge
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LosslessBadge(text = message.mediaResolution ?: "48MP RAW")

                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0x66000000))
                        .padding(5.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FitScreen,
                        contentDescription = "Expand Fullscreen",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            // Bottom metadata bar
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color(0xCC060A14))
                        )
                    )
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = message.mediaName ?: "RAW_IMAGE.DNG",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = sizeMb,
                        color = LiquidCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Checksum guarantee row
        message.mediaChecksum?.let { hash ->
            Row(
                modifier = Modifier
                    .padding(horizontal = 6.dp, vertical = 4.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = null,
                    tint = LiquidEmerald,
                    modifier = Modifier.size(11.dp)
                )
                Text(
                    text = hash,
                    color = Color(0xFF98A7C2),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun LosslessVideoCard(
    message: MessageEntity,
    onOpenViewer: () -> Unit
) {
    var isPlaying by remember { mutableStateOf(false) }
    var playbackProgress by remember { mutableFloatStateOf(0.25f) }
    val sizeMb = String.format(Locale.US, "%.1f MB", message.mediaSizeBytes / (1024f * 1024f))

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .liquidGlass(
                shape = RoundedCornerShape(18.dp),
                backgroundColor = Color(0x3819263E),
                borderBrush = LiquidGlassBorderBrush
            )
            .clickable { onOpenViewer() }
            .padding(6.dp)
            .testTag("lossless_video_card_${message.id}")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(14.dp))
        ) {
            AsyncImage(
                model = message.mediaUri,
                contentDescription = "4K Video Preview",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Center play button with liquid glass
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(Color(0x55000000))
                    .border(1.2.dp, LiquidGlassBorderBrush, CircleShape)
                    .clickable { isPlaying = !isPlaying },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = LiquidCyan,
                    modifier = Modifier.size(28.dp)
                )
            }

            // Top Badges
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LosslessBadge(
                    text = message.mediaResolution ?: "4K PRORES 60FPS",
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            modifier = Modifier.size(11.dp),
                            tint = LiquidMagenta
                        )
                    }
                )

                Text(
                    text = "00:48 / 02:14",
                    color = Color.White,
                    fontSize = 10.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x66000000))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                )
            }

            // Progress bar
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(4.dp)
                    .background(Color(0x44FFFFFF))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(playbackProgress)
                        .height(4.dp)
                        .background(LiquidCyan)
                )
            }
        }

        // Info footer
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = message.mediaName ?: "LOSSLESS_CAPTURE.MOV",
                    color = Color.White,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Zero frame drop • 10-bit HDR • $sizeMb",
                    color = Color(0xFFA5B4CD),
                    fontSize = 9.5.sp
                )
            }
        }
    }
}

@Composable
fun LosslessDocumentCard(
    message: MessageEntity
) {
    var isDownloaded by remember { mutableStateOf(false) }
    val sizeMb = String.format(Locale.US, "%.1f MB", message.mediaSizeBytes / (1024f * 1024f))

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .liquidGlass(
                shape = RoundedCornerShape(16.dp),
                backgroundColor = Color(0x351B2742),
                borderBrush = LiquidGlassBorderBrush
            )
            .padding(12.dp)
            .testTag("lossless_document_card_${message.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Document icon in glass circle
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF223555), Color(0xFF16233B))))
                .border(1.dp, LiquidGlassBorderBrush, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Description,
                contentDescription = "Document",
                tint = LiquidCyan,
                modifier = Modifier.size(24.dp)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = message.mediaName ?: "document.pdf",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = sizeMb,
                    color = LiquidCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "•",
                    color = Color(0xFF70809C),
                    fontSize = 10.sp
                )
                Text(
                    text = "Original Lossless Hash",
                    color = Color(0xFF94A5C2),
                    fontSize = 9.5.sp
                )
            }
        }

        IconButton(
            onClick = { isDownloaded = !isDownloaded },
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(if (isDownloaded) Color(0x3300F5A0) else Color(0x22FFFFFF))
                .border(
                    1.dp,
                    if (isDownloaded) LiquidEmerald.copy(alpha = 0.5f) else LiquidGlassBorder,
                    CircleShape
                )
        ) {
            Icon(
                imageVector = if (isDownloaded) Icons.Default.Verified else Icons.Default.Download,
                contentDescription = "Download File",
                tint = if (isDownloaded) LiquidEmerald else Color.White,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun LosslessVoicePlayer(
    message: MessageEntity
) {
    var isPlaying by remember { mutableStateOf(false) }
    var currentPlayhead by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            val totalSeconds = message.audioDurationSeconds.coerceAtLeast(1)
            while (currentPlayhead < 1f && isPlaying) {
                kotlinx.coroutines.delay(100)
                currentPlayhead += (0.1f / totalSeconds)
            }
            if (currentPlayhead >= 1f) {
                currentPlayhead = 0f
                isPlaying = false
            }
        }
    }

    val waveHeights = remember(message.audioWaveform) {
        message.audioWaveform?.split(",")?.mapNotNull { it.trim().toIntOrNull() }
            ?: listOf(30, 50, 80, 45, 95, 100, 70, 85, 40, 60, 90, 75, 50, 30, 65, 80, 40, 20)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .liquidGlass(
                shape = RoundedCornerShape(18.dp),
                backgroundColor = Color(0x3018243C),
                borderBrush = LiquidGlassBorderBrush
            )
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .testTag("lossless_voice_player_${message.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Play button
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(LiquidCyan, LiquidViolet)))
                .clickable { isPlaying = !isPlaying },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = "Play Voice Note",
                tint = Color.Black,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        // Waveform Bars
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                waveHeights.forEachIndexed { index, heightPercent ->
                    val fraction = index.toFloat() / waveHeights.size
                    val isPassed = fraction <= currentPlayhead
                    val barHeight = (heightPercent / 100f * 24f).coerceAtLeast(4f).dp

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(barHeight)
                            .clip(RoundedCornerShape(2.dp))
                            .background(
                                if (isPassed) LiquidCyan
                                else Color(0x5590A8D0)
                            )
                    )
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Opus Studio 48kHz",
                    color = LiquidCyan,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "${message.audioDurationSeconds}s",
                    color = Color(0xFFBACADB),
                    fontSize = 9.5.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun FullscreenLosslessViewerDialog(
    message: MessageEntity,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xF0060912))
        ) {
            // Main content
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 70.dp, bottom = 120.dp),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = message.mediaUri,
                    contentDescription = "Lossless Fullscreen",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp, start = 16.dp, end = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LosslessBadge(text = "UNCOMPRESSED BITSTREAM")
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0x44FFFFFF))
                        .border(1.dp, LiquidGlassBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Viewer",
                        tint = Color.White
                    )
                }
            }

            // Bottom glass metadata inspection panel
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp)
                    .liquidGlass(
                        shape = RoundedCornerShape(22.dp),
                        backgroundColor = Color(0x4D121B2F),
                        borderBrush = LiquidGlassBorderBrush
                    )
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = message.mediaName ?: "LOSSLESS_ASSET",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = message.mediaResolution ?: "Native Resolution",
                            color = LiquidCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Text(
                        text = String.format(Locale.US, "%.1f MB", message.mediaSizeBytes / (1024f * 1024f)),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = LiquidEmerald,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = message.mediaChecksum ?: "SHA-256: Bit-exact verified transmission",
                        color = Color(0xFFBACADE),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
