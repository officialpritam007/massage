package com.example

import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testGroupEntityCreation() {
    val group = com.example.data.model.GroupEntity(
      id = "grp_test",
      name = "Liquid Engineering",
      avatarUrl = "https://example.com/avatar.png",
      description = "Test channel",
      memberIds = "elena,liam,aiko",
      lastMessage = "Hello",
      lastMessageTime = 1000L,
      category = "Engineering"
    )
    assertEquals("grp_test", group.id)
    assertEquals(3, group.memberIds.split(",").size)
    assertEquals("Engineering", group.category)
  }
}
